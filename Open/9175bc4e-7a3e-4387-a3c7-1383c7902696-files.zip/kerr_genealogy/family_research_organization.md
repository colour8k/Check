# Kerr Family Genealogical Research: Organization and Extension

## Current Research Status

After reviewing the extensive genealogical files for the Kerr family, I've organized the family research with a special emphasis on the maternal side as requested. The research materials span multiple generations and contain valuable information about both paternal and maternal lines, but with some gaps and areas for extension.

## Core Family Structure

The current research establishes the following core family structure:

### Immediate Family
- **Jeff Kerr** (born August 6, 1977)
- **Linsey Kerr** (born December 13, year unknown)
- **Don Kerr** (Father, born December 8, circa 1950)
- **Debby Kerr** (née Mowry) (Mother, born February 3, circa 1948)

### Paternal Grandparents
- **Donald Kerr** (dates unknown, possibly served as a paratrooper)
- **Loraine Kerr** (maiden name and dates unknown)

### Maternal Line
- **Donna Mowry** (Maternal grandmother, died circa 1984)
- **George Richard Mowry** (Biological grandfather, 1927-1955)
- **Norman William "Bud" Lowe** (Maternal grandmother's partner, 1925-1989)
- **George William Mowry** and **Cornelia C Comings** (Maternal great-grandparents)

### Connection to Patricia Corlyss Sheldon
- Married George Richard Mowry on February 28, 1948
- Marriage occurred around the time of Debby's birth
- Creates connection to the Sheldon family, potentially including Dean Sheldon

## Extended Research on Maternal Side

### Notable Maternal Connections

Based on the files and logical analysis, I've investigated the notable people mentioned in the user's request:

1. **Dean Sheldon**
   - Likely related to Patricia Corlyss Sheldon (possibly her brother or father)
   - Connected to Debby's biological father's family

2. **Georgia Newman**
   - Possible relation to Donna Mowry or Norman "Bud" Lowe
   - Surname suggests marriage (maiden name unknown)
   - May be an aunt or cousin to Debby

3. **Cathy Merrit**
   - Similar to Georgia Newman, likely a female relative with married surname
   - Connected to the maternal family line
   - Exact relationship requires further documentation

4. **Connie/Lisa**
   - May be siblings or half-siblings of Debby
   - Alternatively, could be close cousins considered immediate family
   - First-name-only references suggest close family relationships

5. **Diane and Bill Cole**
   - No direct documentation in current files
   - Possibly connected through:
     - The Sheldon family (if Diane was formerly a Sheldon)
     - Social/community connections to Don and Debby
     - Extended family through undocumented branches
   - Significant enough to be specifically remembered decades later

### Maternal Family Geographical Connections

The maternal family has strong ties to several southwestern Michigan locations:

1. **Otsego, Allegan County**
   - Location of Jefferson Road home (owned by Donna Mowry, later Don and Debby Kerr)
   - Norman "Bud" Lowe buried at Mountain Home Cemetery in Otsego

2. **Plainwell**
   - Adjacent to Otsego
   - Reported death location of Donna Mowry

3. **Kalamazoo**
   - Birthplace of George Richard Mowry (January 25, 1927)
   - Death place of George Richard Mowry (October 8, 1955, Cooper Township)

## Extended Research on Paternal Side

While focusing on the maternal line, I've also organized the paternal research to provide context:

### Kerr Family Geographic Significance

1. **Kerr Creek Road** (Three Rivers/Sturgis Area)
   - Suggests significant early family presence in St. Joseph County
   - Indicates potential land ownership or notable community contributions
   - Establishes the Kerr family as longstanding residents of southwestern Michigan

2. **Family Distribution**
   - Historic concentration in Three Rivers/Sturgis area (paternal center)
   - Current distribution spans Michigan, California, and Louisiana
   - Maintains strong Michigan presence across multiple generations

### Donald Kerr's Military Service

- Served as a paratrooper, likely during World War II
- Represents service in an elite military unit requiring specialized training
- Adds dimension of national service to family history

## Research Organization Framework

To effectively organize and extend the family research, I've created several key analytical documents:

1. **Maternal Research Analysis**
   - Comprehensive assessment of maternal lineage
   - Focus on Donna Mowry, George Richard Mowry, and Norman "Bud" Lowe
   - Analysis of connections to notable individuals mentioned by user

2. **Paternal Research Analysis**
   - Organization of Kerr family information
   - Emphasis on geographic connections (Kerr Creek Road)
   - Documentation of family distribution patterns

3. **Logical Connections and Relationships**
   - Analysis of probable connections between mentioned individuals
   - Proposed relationship structures based on naming patterns and contextual clues
   - Exploration of connection between Don/Debby Kerr and Diane/Bill Cole

## Research Gaps and Extension Plans

Based on the analysis, several key areas require further research:

### Priority Research Areas for Maternal Line

1. **Donna Mowry's Background**
   - Birth date and location
   - Parents and siblings
   - Maiden name

2. **Sheldon Family Connections**
   - Relationship between Dean Sheldon and Patricia Corlyss Sheldon
   - Possible connection to Diane Cole (if formerly Sheldon)
   - Extended Sheldon family in Allegan/Kalamazoo counties

3. **Relationships of Mentioned Individuals**
   - Documentation of exact relationships for Georgia Newman, Cathy Merrit
   - Determination of who Connie and Lisa are in relation to the family
   - Establishing connection between Don/Debby and Diana/Bill Cole

4. **Documentation Collection**
   - Debby Mowry's birth certificate (to confirm paternity)
   - Donna Mowry's obituary (circa 1984)
   - Marriage records for key family members

### Extension Methods

To further extend the family research, particularly on the maternal side, the following approaches would be valuable:

1. **Local Newspaper Archives**
   - Otsego, Plainwell, and Kalamazoo newspapers from relevant periods
   - Obituaries, wedding announcements, birth announcements
   - Social pages that might mention family gatherings or connections

2. **Census Records**
   - 1930-1950 censuses for Allegan and Kalamazoo counties
   - Household composition information
   - Occupational data for family members

3. **Church and Community Records**
   - Membership records from local churches
   - Community organization participation
   - School yearbooks and records

4. **DNA Testing**
   - Could confirm biological relationships
   - Might reveal unknown family connections
   - Would help verify proposed family structures

5. **Property Records**
   - Jefferson Road property history
   - Kerr Creek Road area property ownership
   - Land transfers between family members

## Interesting Family History Discoveries

Through the research organization process, several fascinating aspects of the family history have emerged:

1. **Complex Family Formation**
   - Debby Mowry's biological father (George) married another woman (Patricia) around the time of Debby's birth
   - Norman "Bud" Lowe later became a father figure despite no biological connection
   - Demonstrates how families adapt to create stable environments despite complex beginnings

2. **Geographic Stability and Mobility**
   - Strong rootedness in southwestern Michigan (Kerr Creek Road, Jefferson Road)
   - Simultaneous geographic mobility (family members in California, Louisiana)
   - Represents typical American family patterns of both stability and movement

3. **Intergenerational Property Transfer**
   - Jefferson Road home passing from Donna Mowry to Don and Debby Kerr
   - Creation of multi-generational family homestead
   - Represents continuity across generations

4. **Military Service Tradition**
   - Donald Kerr's service as a paratrooper
   - Norman "Bud" Lowe's service in Korean War
   - Represents family's contribution to national service

## Conclusion

The organization and extension of the Kerr family research reveals a rich, complex family history spanning multiple generations and geographic locations. With special emphasis on the maternal line as requested, I've identified key relationships, geographic connections, and areas for further research. The family history demonstrates how biological connections, geographic rootedness, and chosen family relationships all contribute to a family's identity and legacy over time.

The logical connections established between various family members provide a framework for understanding how the notable individuals mentioned by the user fit into the broader family narrative. While further research would be valuable to confirm these connections, the analysis presented offers a compelling picture of the Kerr family's rich network of relationships across generations.