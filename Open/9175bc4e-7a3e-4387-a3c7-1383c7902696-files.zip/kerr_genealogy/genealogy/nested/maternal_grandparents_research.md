# Research Report: Maternal Grandparents - Donna Mowry and Norman William "Bud" Lowe

## Norman William "Bud" Lowe

### Vital Information
- **Full Name**: Norman William Lowe
- **Nickname**: "Bud"
- **Birth**: April 3, 1925
- **Death**: October 3, 1989 (age 64)
- **Burial**: Mountain Home Cemetery, Otsego, Allegan County, Michigan
- **Military Service**: Corporal, US Army, Korea (as indicated on gravestone)

### Sources
- Ancestry.com U.S. Find a Grave Index record showing Norman W. Lowe with exact birth and death dates
- Family records confirming his nickname "Bud"
- Burial information from Mountain Home Cemetery records

### Relationship to Donna Mowry
Based on the research conducted, Norman William "Bud" Lowe was the long-term partner of Donna Mowry. He was not Debby Mowry's biological father but served as a stepfather figure in her life. His residence in Otsego, Allegan County, Michigan coincides with the location where Donna Mowry lived on Jefferson Road.

### Timeline
- Born April 3, 1925
- Served in the Korean War as a Corporal in the US Army (likely early 1950s)
- Likely began relationship with Donna Mowry after her relationship with George Richard Mowry ended
- Lived with Donna in Otsego, Michigan for many years
- Present during Jeff Kerr's childhood as his grandmother's partner
- Survived Donna Mowry (who died circa 1984) by about 5 years
- Died October 3, 1989

### Connection to Property
The research confirms Norman's connection to Otsego through his burial at Mountain Home Cemetery, which is located in the same town as the Jefferson Road property owned by Donna Mowry, supporting the family account of their relationship.

## Donna Mowry

### Vital Information
- **Full Name**: Donna Mowry (maiden name currently unknown)
- **Birth**: Date unknown, likely 1920s-1930s
- **Death**: Approximately March 5, 1984 in Plainwell, Michigan
- **Burial**: Likely in Allegan County, Michigan (exact location not yet confirmed)

### Sources
- Family records indicating her death when grandson Jeff Kerr was about 9 years old (circa 1984)
- Property records showing ownership of home on Jefferson Road in Otsego, Michigan
- Birth record of daughter Debby Mowry (circa 1948)

### Relationships
1. **Relationship with George Richard Mowry**:
   - Based on the research, Donna had a relationship with George Richard Mowry that resulted in the birth of her daughter Debby around 1948
   - This relationship appears to have occurred around the same time George married Patricia Corlyss Sheldon (February 28, 1948)
   - The relationship ended, possibly due to George's marriage to Patricia
   - George died in 1955 when Debby would have been about 7 years old

2. **Relationship with Norman William "Bud" Lowe**:
   - After her relationship with George ended, Donna formed a long-term relationship with Norman "Bud" Lowe
   - They lived together in Donna's home on Jefferson Road in Otsego
   - Norman served as a father figure to Debby
   - Their relationship continued until Donna's death in 1984

### Children
- **Debby Mowry** (born February 3, circa 1948):
  - Biological father: George Richard Mowry
  - Later married Don Kerr
  - Had two children: Jeff Kerr (born August 6, 1977) and Linsey Kerr (born December 13, year unknown)

### Property Ownership
Donna owned a home on Jefferson Road in Otsego, Allegan County, Michigan. This property was later purchased by her daughter Debby and son-in-law Don Kerr, becoming the childhood home of Jeff and Linsey Kerr.

## Confirmed Information About the Maternal Grandparents

1. **Correct Spelling of Surname**: Research confirms the spelling is "Mowry" (not "Morey")

2. **Full Identity of "Bud"**: Norman William Lowe (April 3, 1925 - October 3, 1989)

3. **Relationship Dynamics**: 
   - Donna Mowry had a relationship with George Richard Mowry that resulted in daughter Debby
   - Later, Donna formed a long-term relationship with Norman "Bud" Lowe
   - Norman was not Debby's biological father but served as a father figure

4. **Geographic Connections**:
   - Both Donna and Norman resided in Otsego, Allegan County, Michigan
   - Norman is buried in Mountain Home Cemetery in Otsego
   - Donna's reported death location is Plainwell, Michigan (adjacent to Otsego)

5. **Military Service**: Norman "Bud" Lowe served as a Corporal in the US Army during the Korean War

## Timeline of Key Events

1. **April 3, 1925**: Birth of Norman William "Bud" Lowe
2. **April 25, 1927**: Birth of George Richard Mowry (Debby's biological father)
3. **Early 1948**: Relationship between Donna Mowry and George Richard Mowry
4. **February 28, 1948**: George Richard Mowry marries Patricia Corlyss Sheldon
5. **Circa February 1948**: Birth of Debby Mowry
6. **Early 1950s**: Possible beginning of relationship between Donna Mowry and Norman "Bud" Lowe (after his Korean War service)
7. **October 8, 1955**: Death of George Richard Mowry
8. **March 5, 1984**: Death of Donna Mowry in Plainwell, Michigan
9. **October 3, 1989**: Death of Norman William "Bud" Lowe

## Ongoing Research Questions

1. **Donna Mowry's Maiden Name**: No records have yet been found indicating Donna's maiden name. Research in marriage records and her birth certificate would be needed.

2. **Formal Marriage Status**: It remains unclear whether Donna Mowry and Norman William Lowe were legally married or were long-term partners without formal marriage.

3. **Possible Connection to Other Individuals**: The relationship of Conny/Connie, Bruce, Georgia Newman, and Dean to the Mowry family remains unclear. These individuals could be siblings of Donna, siblings of Norman, or have other family connections.

4. **Donna Mowry's Birth Information**: No records have yet been found regarding Donna's birth date and place. Further research in birth and census records is needed.

5. **Donna Mowry's Death Record**: While family information indicates she died around March 5, 1984, in Plainwell, Michigan, no official death record has yet been located to confirm this information.

## Recommendations for Further Research

1. **Search for Donna Mowry's Obituary**: Local newspapers from Plainwell/Otsego area from March 1984 should be researched for her obituary, which might provide details about her family relationships.

2. **Locate Marriage Records**: Check Allegan County marriage records for any formal marriage between Norman William Lowe and Donna Mowry.

3. **Research Property Records**: Investigate Jefferson Road property records in Otsego to confirm Donna's ownership and the transfer to Don and Debby Kerr.

4. **U.S. Census Records**: Search the 1940 and 1950 census records for both Donna and Norman to gather additional information about their early lives.

5. **Military Records**: Request Norman William Lowe's military service records from the National Archives to confirm his service details and potentially find additional personal information.

6. **Social Security Applications**: Researching Social Security applications for both Donna and Norman might provide additional details about their parents and birthplaces.