# Relationship Analysis: George Richard Mowry and Donna Mowry

## Overview

This document explores the relationship between George Richard Mowry and Donna Mowry, focusing on their connection as the biological parents of Debby Mowry (later Kerr), who is the maternal grandmother of Jeff and Linsey Kerr. Based on the research conducted, we can establish several key facts about their relationship and its significance in the family history.

## Confirmed Facts About George Richard Mowry

1. **Full Name**: George Richard Mowry
2. **Birth**: April 25, 1927, Kalamazoo, Michigan
3. **Death**: October 8, 1955, Cooper Township, Kalamazoo, Michigan (age 28)
4. **Burial**: Oak Grove Cemetery, Galesburg, Kalamazoo, Michigan
5. **Parents**: George William Mowry (1907-1953) and Cornelia C. Comings (1908-1997)
6. **Military Service**: Registered for military service in 1946
7. **Marriage**: 
   - Spouse: Patricia Corlyss Sheldon
   - Marriage Date: February 28, 1948
   - Marriage Place: Otsego Township, Allegan, Michigan
8. **Residence**:
   - 1930: Lived in Comstock, Kalamazoo, Michigan (as shown in census)
   - 1940: Lived in Otsego, Allegan, Michigan (as shown in census)

## Timeline of the Relationship

The relationship between George Richard Mowry and Donna Mowry can be pieced together through the available documentation and family accounts:

1. **1940s**: George Richard Mowry and Donna Mowry have a relationship in Otsego, Allegan County, Michigan.

2. **Late 1947/Early 1948**: Donna becomes pregnant with Debby.

3. **February 28, 1948**: George Richard Mowry marries Patricia Corlyss Sheldon in Otsego Township, Allegan County, Michigan. This marriage occurs around the same time that Donna is pregnant with or has recently given birth to Debby.

4. **Circa February 1948**: Birth of Debby Mowry to Donna. George Richard Mowry is the biological father, though he has just married another woman.

5. **1948-1955**: Limited or no contact between George and his daughter Debby (speculative, based on his marriage to another woman).

6. **October 8, 1955**: Death of George Richard Mowry at age 28 in Cooper Township, Kalamazoo, Michigan. At this time, Debby would have been approximately 7 years old.

## Nature of the Relationship

Based on the timing of events, particularly George's marriage to Patricia Sheldon in February 1948 and the birth of Debby around the same time, several possibilities exist regarding the nature of George and Donna's relationship:

1. **Brief Relationship**: They may have had a brief relationship or affair that ended before or around the time Donna became pregnant.

2. **Relationship During Engagement**: George may have been in a relationship with Donna while engaged to Patricia, with the pregnancy occurring shortly before his marriage.

3. **Overlapping Relationships**: George may have been involved with both women simultaneously, ultimately choosing to marry Patricia despite Donna's pregnancy.

4. **Failed Relationship**: They may have had a more serious relationship that ended, with George moving on to marry Patricia despite knowing about Donna's pregnancy.

The exact nature of their relationship cannot be definitively established without additional documentation, such as personal correspondence, legal records, or firsthand accounts from people who knew them.

## Impact on Family Structure

The relationship between George and Donna, and the subsequent events, had significant implications for the family structure:

1. **Single Parenthood**: Donna appears to have raised Debby as a single mother initially, given George's marriage to another woman.

2. **Absence of Biological Father**: With George marrying someone else and then dying when Debby was only about 7 years old, Debby grew up without her biological father's presence.

3. **Creation of Blended Family**: Norman William "Bud" Lowe later entered Donna's life and became a father figure to Debby, creating a blended family structure.

4. **Hidden Family History**: The biological connection to George Richard Mowry may not have been widely discussed within the family, as evidenced by the uncertainty about "Bud" Lowe's relationship to Debby in the initial family information.

5. **Extended Family Connections**: Through George, Debby has biological connections to the Mowry and Comings families, including grandparents George William Mowry and Cornelia C. Comings.

## Geographic Connections

The geographic proximity of George and Donna during their relationship is notable:

1. **Otsego, Allegan County**: The 1940 census shows George living in Otsego, which is the same town where Donna owned property on Jefferson Road. This geographic connection supports the possibility of their relationship.

2. **Kalamazoo-Allegan Connection**: George was born in Kalamazoo and died in Cooper Township, Kalamazoo County, while maintaining connections to Allegan County through his marriage in Otsego Township and his previous residence there. The proximity of these locations (approximately 20 miles apart) allowed for movement between the two areas.

## Cultural and Historical Context

The relationship between George and Donna, and the birth of Debby, should be understood within the cultural and historical context of post-World War II America:

1. **Post-War Social Changes**: The late 1940s saw significant social changes as servicemen returned from war and established families, often with shifting relationship dynamics.

2. **Unwed Motherhood Stigma**: There was significant stigma attached to unwed motherhood in the late 1940s, which may have influenced how Donna's pregnancy and single parenthood were perceived and discussed.

3. **Limited Options**: Women who became pregnant outside of marriage in the 1940s had limited options and often faced significant social and economic challenges.

4. **Family Privacy**: Family situations that didn't conform to social norms were often not openly discussed, potentially explaining why the details of Debby's paternity may not have been widely shared within the family.

## Evidence and Documentation Gaps

Several aspects of George and Donna's relationship remain unclear due to documentation gaps:

1. **No Direct Evidence of Relationship**: There are no currently known documents (letters, photographs, etc.) that directly confirm a relationship between George and Donna.

2. **Debby's Birth Certificate**: Debby's birth certificate, which might confirm George as her father, has not been located.

3. **Nature of Relationship End**: How and why their relationship ended is unknown, though George's marriage to Patricia provides a possible endpoint.

4. **Donna's Background**: Limited information is available about Donna's life before and during her relationship with George.

5. **George's Marriage Timing**: The very close timing between George's marriage to Patricia and the birth of Debby raises questions about the circumstances surrounding these events.

## Recommendations for Further Research

To better understand the relationship between George and Donna, the following research avenues are recommended:

1. **Debby's Birth Certificate**: Locating Debby's birth certificate would potentially confirm George as her father and provide a precise birth date.

2. **Newspaper Archives**: Local newspapers from Otsego and Kalamazoo from the 1947-1948 period might contain announcements, social news, or other information about George, Donna, or the birth of Debby.

3. **Court Records**: Any court records related to paternity, child support, or other legal matters between George and Donna could provide insights into their relationship.

4. **George's Marriage Records**: A detailed review of George's marriage to Patricia might provide additional context about the timing relative to Debby's birth.

5. **Interviews with Living Relatives**: If possible, interviews with living relatives who might have knowledge about George and Donna's relationship could provide valuable firsthand accounts.

6. **DNA Testing**: DNA testing of living descendants could provide scientific confirmation of the biological relationship between George and Debby's descendants.

## The Mowry Family Connection

Through George Richard Mowry, Debby and her descendants connect to the broader Mowry family:

1. **Paternal Grandparents**: George William Mowry (1907-1953) and Cornelia C. Comings (1908-1997) are Debby's biological grandparents.

2. **Family Name Origin**: The Mowry surname is of English origin, likely a variant of the Anglo-Norman French personal name Mory, a short form of Amaury.

3. **Extended Family**: Research into George's siblings (if any) could reveal additional relatives connected to Debby through the Mowry and Comings lines.

## Conclusion

The relationship between George Richard Mowry and Donna Mowry, while brief and not resulting in marriage, had a lasting impact on the family through their daughter Debby. Despite George's absence from Debby's life due to his marriage to another woman and his early death, the biological connection has significance for understanding the full family history of the Kerr/Mowry families. This relationship highlights how family histories often include complex relationships and connections that shaped subsequent generations, even when those connections were not maintained through ongoing personal relationships.