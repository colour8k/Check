# Relationship Analysis: Norman William "Bud" Lowe and Donna Mowry

## Overview

This document explores the relationship between Norman William "Bud" Lowe and Donna Mowry, focusing on their connection, the timeline of their relationship, and their role in the family structure. Based on the research conducted, we can establish several key facts about their relationship and its significance in the Kerr family history.

## Confirmed Facts About the Relationship

1. **Identity Confirmation**: Norman William Lowe (April 3, 1925 - October 3, 1989) has been confirmed as the "Bud" mentioned in family records who was Donna Mowry's partner during Jeff Kerr's childhood.

2. **Geographic Connection**: Both Norman and Donna lived in Otsego, Allegan County, Michigan. Norman's burial at Mountain Home Cemetery in Otsego confirms his connection to this location, which is the same town where Donna owned property on Jefferson Road.

3. **Timeline Relationship**: Norman outlived Donna by approximately 5 years. Donna reportedly died around March 5, 1984, while Norman died on October 3, 1989.

4. **Household Structure**: They shared the home on Jefferson Road in Otsego, which later became the family home of Don and Debby Kerr and the childhood home of Jeff and Linsey Kerr.

5. **Family Role**: Norman served as a father figure to Debby Mowry (despite not being her biological father), making him a step-grandfather figure to Jeff and Linsey Kerr.

## Timeline of Relationship

While the exact beginning of their relationship is not documented in the current research, we can establish a likely timeline:

1. **Prior to 1950s**: Donna Mowry has a relationship with George Richard Mowry, resulting in the birth of Debby around February 1948.

2. **Early 1950s**: Norman "Bud" Lowe likely serves in the Korean War (based on his military designation as shown on his gravestone).

3. **Mid-1950s**: Following his military service and possibly after the death of George Richard Mowry in 1955, Norman likely begins his relationship with Donna Mowry.

4. **1955-1984**: Norman and Donna maintain a long-term relationship, residing together at the home on Jefferson Road in Otsego.

5. **March 1984**: Donna Mowry passes away in Plainwell, Michigan.

6. **1984-1989**: Norman continues to live for approximately 5 years after Donna's death.

7. **October 3, 1989**: Norman passes away at age 64.

## Nature of the Relationship

Based on the available information, several possibilities exist regarding the formal nature of Norman and Donna's relationship:

1. **Legal Marriage**: They may have been legally married, though no marriage certificate has yet been located.

2. **Long-term Partnership**: They may have been in a committed relationship without formal marriage, which was less common but still occurred in the mid-20th century.

3. **Common-law Marriage**: Michigan did not recognize common-law marriages contracted after January 1, 1957, but if their relationship began before this date, they might have been considered married under common law.

## Family Structure Impact

Norman and Donna's relationship had significant implications for the family structure:

1. **Blended Family Creation**: Norman became a father figure to Debby Mowry, creating a blended family structure following the apparent absence of Debby's biological father, George Richard Mowry.

2. **Continuity for Debby**: With George Richard Mowry dying when Debby was only about 7 years old, Norman's presence provided continuity and a male parental figure during her formative years.

3. **Grandparent Role**: For Jeff Kerr, Norman was the grandfather figure he knew during his childhood, despite not being biologically related. This relationship shaped Jeff's understanding of his maternal family connections.

4. **Property Legacy**: The home Norman shared with Donna on Jefferson Road eventually became the family home for the next generation (Don and Debby Kerr), creating a physical connection between generations.

## Cultural and Historical Context

The relationship between Norman and Donna should be understood within the cultural and historical context of mid-20th century America:

1. **Post-War Family Formation**: Their relationship likely formed in the post-Korean War era when many veterans returned home and established families.

2. **Rural Michigan Community**: Otsego, being a smaller community in Allegan County, would have had different social norms regarding family formation than urban areas in the same period.

3. **Blended Families**: While less openly acknowledged than today, blended families formed through relationships with partners who had children from previous relationships were not uncommon in the mid-20th century.

## Evidence of Relationship Characteristics

While detailed information about the day-to-day nature of their relationship is limited, certain aspects can be inferred:

1. **Stability**: The long-term nature of their relationship (likely spanning decades) suggests stability and commitment.

2. **Acceptance by Extended Family**: The fact that Norman was known to Jeff as his grandmother's partner indicates he was accepted as part of the family structure.

3. **Property Sharing**: Their shared residence on Jefferson Road suggests a committed domestic partnership.

4. **Continuity Across Generations**: The later transfer of the Jefferson Road property to Don and Debby suggests Norman and Donna's relationship created a stable enough environment to establish a multi-generational family home.

## Research Gaps and Questions

Several aspects of Norman and Donna's relationship remain unclear and would benefit from further research:

1. **Beginning of Relationship**: When did Norman and Donna first meet and begin their relationship?

2. **Legal Status**: Were they legally married, and if so, when and where did the marriage take place?

3. **Previous Relationships**: Did Norman have any marriages or children prior to his relationship with Donna?

4. **Social Recognition**: How was their relationship viewed and acknowledged within the Otsego community?

5. **Other Children**: Did Donna have children other than Debby, possibly explaining the connection to individuals named Conny/Connie, Bruce, Georgia Newman, and Dean?

## Recommendations for Further Research

To better understand the relationship between Norman and Donna, the following research avenues are recommended:

1. **Local Newspaper Archives**: Newspapers from Otsego and surrounding areas might contain social news mentioning Norman and Donna together, particularly from the 1950s-1980s period.

2. **Donna's Obituary**: If located, Donna's 1984 obituary might mention Norman as her husband or partner, clarifying their relationship status.

3. **Norman's Obituary**: Similarly, Norman's 1989 obituary might reference his relationship with Donna.

4. **Property Records**: Detailed research of the Jefferson Road property ownership could reveal how the property was titled (individual or joint ownership) and when it transferred to Don and Debby Kerr.

5. **Marriage Records**: A comprehensive search of Allegan County marriage records could confirm whether a legal marriage took place.

6. **Interviews with Living Relatives**: If possible, interviews with living relatives who knew Norman and Donna could provide valuable insights into the nature of their relationship.

## Conclusion

Norman William "Bud" Lowe and Donna Mowry shared a significant long-term relationship that played an important role in the family history of the Kerr/Mowry families. While Norman was not biologically related to the Kerr family, his relationship with Donna and his role as a father figure to Debby and grandfather figure to Jeff and Linsey makes him an important part of the family narrative. This relationship represents the blended nature of the family and highlights how family connections extend beyond biological relationships to include those who fulfill important familial roles through long-term commitment and presence.