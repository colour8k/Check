# Kerr Family Comprehensive Database

## Core Family Members

### Jeff Kerr (Primary Family Member)
- **Full Name:** Jeff Kerr
- **Birth:** August 6, 1977
- **Birth Place:** Likely Otsego, Michigan
- **Current Residence:** Grand Rapids, Michigan
- **Parents:** Don Kerr and Debby Kerr (née Mowry)
- **Sibling:** Linsey Kerr
- **Children:**
  - Jude Kerr (mother: Melissa Smith)
  - Lincon Kerr (mother: Melissa Smith)

### Linsey Kerr (Sister)
- **Full Name:** Linsey Kerr
- **Birth:** December 13 (year unknown)
- **Parents:** Don Kerr and Debby Kerr (née Mowry)
- **Sibling:** Jeff Kerr (brother)

## Paternal Line

### Immediate Family

#### Don Kerr (Father)
- **Full Name:** Don Kerr
- **Birth:** December 8, circa 1950
- **Birth Place:** Either Three Rivers or Sturgis, Michigan
- **Residence:** Jefferson Road, Otsego, Michigan (family home purchased from Debby's mother)
- **Parents:** Donald Kerr and Loraine Kerr
- **Spouse:** Debby Kerr (née Mowry)
- **Children:**
  - Jeff Kerr (born August 6, 1977)
  - Linsey Kerr (born December 13, year unknown)
- **Siblings:**
  - Steve Kerr (younger brother, recently deceased overseas)
  - Vanessa Kerr Otsuka (sister, lives in California)
  - Sharron Kerr (sister, deceased at a young age)

#### Debby Kerr (née Mowry) (Mother)
- **Full Name:** Debby Kerr (née Mowry)
- **Birth:** February 3, circa 1948
- **Birth Place:** Likely Otsego, Michigan
- **Residence:** Jefferson Road, Otsego, Michigan (family home purchased from her mother)
- **Parents:**
  - Biological Father: George Richard Mowry (1927-1955)
  - Mother: Donna Mowry
  - Mother's Partner: Norman William "Bud" Lowe
- **Spouse:** Don Kerr
- **Children:**
  - Jeff Kerr (born August 6, 1977)
  - Linsey Kerr (born December 13, year unknown)

### Paternal Grandparents

#### Donald Kerr (Paternal Grandfather)
- **Full Name:** Donald Kerr
- **Birth Date:** Unknown (likely 1920s-1930s)
- **Birth Place:** Unknown (likely Michigan)
- **Residence:** Three Rivers or Sturgis area, St. Joseph County, Michigan
- **Spouse:** Loraine Kerr
- **Children:**
  - Don Kerr (born December 8, circa 1950)
  - Steve Kerr (younger than Don, recently deceased)
  - Vanessa Kerr (now Otsuka)
  - Sharron Kerr (deceased at a young age)
- **Possible Military Service:** Suggested by research files

#### Loraine Kerr (Paternal Grandmother)
- **Full Name:** Loraine Kerr (maiden name unknown)
- **Birth Date:** Unknown (likely 1920s-1930s)
- **Birth Place:** Unknown (likely Michigan)
- **Residence:** Three Rivers or Sturgis area, St. Joseph County, Michigan
- **Spouse:** Donald Kerr
- **Children:**
  - Don Kerr (born December 8, circa 1950)
  - Steve Kerr (younger than Don, recently deceased)
  - Vanessa Kerr (now Otsuka)
  - Sharron Kerr (deceased at a young age)

### Paternal Aunts and Uncles

#### Steve Kerr (Paternal Uncle)
- **Full Name:** Steve Kerr
- **Birth:** Unknown (younger than Don Kerr)
- **Death:** Recently deceased overseas in tropical location
- **Parents:** Donald and Loraine Kerr
- **Marriages:**
  - First Marriage: Wife's name unknown
    - Children: Jeremy Kerr, Heather Kerr
  - Second Marriage: Debby Kerr (currently in Kalamazoo)
    - Children: Daniel Kerr, Ryan Kerr
- **Siblings:** Don Kerr, Vanessa Kerr Otsuka, Sharron Kerr

#### Vanessa Kerr Otsuka (Paternal Aunt)
- **Full Name:** Vanessa Kerr Otsuka
- **Birth:** Unknown
- **Residence:** California
- **Parents:** Donald and Loraine Kerr
- **Spouse:** Richard Otsuka
- **Children:** Evan Otsuka, Bobby Otsuka (both played sports)
- **Step-child:** Richard's daughter from previous relationship (name unknown)
- **Siblings:** Don Kerr, Steve Kerr, Sharron Kerr

#### Sharron Kerr (Paternal Aunt, Deceased)
- **Full Name:** Sharron Kerr
- **Birth:** Unknown
- **Death:** Unknown (died young)
- **Parents:** Donald and Loraine Kerr
- **Marriages:**
  - First Marriage: Tom Decker
  - Second Marriage: Dick Grimms
- **Children:** Carey Grimms (with Dick Grimms)
- **Siblings:** Don Kerr, Steve Kerr, Vanessa Kerr Otsuka

### Paternal Cousins

#### Jeremy Kerr (Paternal Cousin)
- **Full Name:** Jeremy Kerr
- **Residence:** Louisiana
- **Parents:** Steve Kerr and his first wife

#### Heather Kerr (Paternal Cousin)
- **Full Name:** Heather Kerr
- **Residence:** Sturgis or Three Rivers, Michigan
- **Parents:** Steve Kerr and his first wife

#### Daniel Kerr (Paternal Cousin)
- **Full Name:** Daniel Kerr
- **Residence:** Detroit, Michigan
- **Parents:** Steve Kerr and his second wife Debby Kerr

#### Ryan Kerr (Paternal Cousin)
- **Full Name:** Ryan Kerr
- **Residence:** Kalamazoo, Michigan (with mother)
- **Parents:** Steve Kerr and his second wife Debby Kerr

#### Evan Otsuka (Paternal Cousin)
- **Full Name:** Evan Otsuka
- **Residence:** California
- **Parents:** Vanessa Kerr Otsuka and Richard Otsuka
- **Note:** Played sports

#### Bobby Otsuka (Paternal Cousin)
- **Full Name:** Bobby Otsuka
- **Residence:** California
- **Parents:** Vanessa Kerr Otsuka and Richard Otsuka
- **Note:** Played sports

#### Carey Grimms (Paternal Cousin)
- **Full Name:** Carey Grimms
- **Parents:** Sharron Kerr and Dick Grimms

## Maternal Line

### Maternal Grandparents

#### Donna Mowry (Maternal Grandmother)
- **Full Name:** Donna Mowry (maiden name unknown)
- **Birth Date:** Unknown (likely 1920s-1930s)
- **Birth Place:** Unknown (likely Michigan)
- **Death Date:** Approximately March 5, 1984 (when grandson Jeff was about 9 years old)
- **Death Place:** Plainwell, Michigan
- **Residence:** Jefferson Road, Otsego, Allegan County, Michigan
- **Relationships:**
  - Relationship with George Richard Mowry (father of Debby)
  - Later relationship with Norman William "Bud" Lowe
- **Children:**
  - Debby Mowry (born February 3, circa 1948)
- **Property:** Owner of home on Jefferson Road in Otsego that was later sold to Don and Debby Kerr

#### George Richard Mowry (Maternal Biological Grandfather)
- **Full Name:** George Richard Mowry
- **Birth:** January 25, 1927, Kalamazoo, Michigan
- **Death:** October 8, 1955, Cooper Township, Kalamazoo, Michigan (age 28)
- **Burial:** Oak Grove Cemetery, Galesburg, Kalamazoo, Michigan
- **Parents:**
  - Father: George William Mowry (1907-1953)
  - Mother: Cornelia C Comings (1908-1997)
- **Spouse:** Patricia Corlyss Sheldon (married February 28, 1948 in Otsego Township, Allegan, Michigan)
- **Relationship with Donna Mowry:** Biological father of Debby Mowry
- **Residence History:**
  - Lived in Comstock, Kalamazoo, Michigan in 1930
  - Lived in Otsego, Allegan, Michigan in 1940
- **Military Service:** Registered for military service in 1946

#### Norman William "Bud" Lowe (Maternal Grandmother's Partner)
- **Full Name:** Norman William Lowe
- **Nickname:** "Bud"
- **Birth Date:** Unknown
- **Birth Place:** Unknown
- **Death Date:** Unknown
- **Residence:** Likely lived with Donna Mowry on Jefferson Road, Otsego, Michigan
- **Relationship to Donna Mowry:** Later boyfriend/partner
- **Relationship to Debby:** Stepfather-like figure (not biological father)

### Possible Maternal Extended Family
These individuals have unclear relationships but may be connected to the maternal line:
- **Conny/Connie:** Relationship unknown
- **Bruce:** Relationship unknown
- **Georgia Newman:** Relationship unknown
- **Dean:** Relationship unknown

## Great-Grandparents (Maternal Line)

### George William Mowry (Maternal Great-Grandfather)
- **Full Name:** George William Mowry
- **Birth:** 1907
- **Death:** 1953
- **Child:** George Richard Mowry (1927-1955)

### Cornelia C Comings (Maternal Great-Grandmother)
- **Full Name:** Cornelia C Comings
- **Birth:** 1908
- **Death:** 1997
- **Child:** George Richard Mowry (1927-1955)

## Location Information

### Paternal Line Locations
- **Three Rivers/Sturgis area (St. Joseph County, Michigan):** Origin of Kerr family
- **California:** Current residence of Vanessa and Richard Otsuka family
- **Louisiana:** Current residence of Jeremy Kerr
- **Detroit, Michigan:** Current residence of Daniel Kerr
- **Kalamazoo, Michigan:** Current residence of Ryan Kerr and his mother Debby Kerr

### Maternal Line Locations
- **Otsego (Allegan County, Michigan):** Family home on Jefferson Road
- **Plainwell (Allegan County, Michigan):** Reported death location of Donna Mowry
- **Kalamazoo, Michigan:** Birth place of George Richard Mowry
- **Cooper Township, Kalamazoo, Michigan:** Death place of George Richard Mowry
- **Galesburg, Kalamazoo, Michigan:** Burial location of George Richard Mowry (Oak Grove Cemetery)

### Current Generation
- **Grand Rapids, Michigan:** Current residence of Jeff Kerr

## Important Dates Timeline

- **1907:** Birth of George William Mowry (maternal great-grandfather)
- **1908:** Birth of Cornelia C Comings (maternal great-grandmother)
- **January 25, 1927:** Birth of George Richard Mowry (maternal biological grandfather)
- **1940s:** Likely marriage of Donald and Loraine Kerr
- **February 3, circa 1948:** Birth of Debby Mowry
- **February 28, 1948:** Marriage of George Richard Mowry to Patricia Corlyss Sheldon
- **December 8, circa 1950:** Birth of Don Kerr
- **1953:** Death of George William Mowry (maternal great-grandfather)
- **October 8, 1955:** Death of George Richard Mowry (maternal biological grandfather) at age 28
- **Unknown Date:** Marriage of Don Kerr and Debby Mowry
- **August 6, 1977:** Birth of Jeff Kerr
- **December 13 (year unknown):** Birth of Linsey Kerr
- **March 5, 1984 (approximate):** Death of Donna Mowry (maternal grandmother)
- **1997:** Death of Cornelia C Comings (maternal great-grandmother)
- **Recent (before May 2025):** Death of Steve Kerr (paternal uncle) overseas

## Identified Research Gaps

1. **Paternal Line Gaps:**
   - Birth certificates for Don, Steve, Vanessa, and Sharron Kerr
   - Marriage certificate for Donald and Loraine Kerr
   - Loraine Kerr's maiden name
   - Birth and death dates for Donald and Loraine Kerr
   - Circumstances of Sharron Kerr's early death
   - Military service records for Donald Kerr

2. **Maternal Line Gaps:**
   - Birth certificate for Debby Mowry
   - Birth and marriage details for Donna Mowry
   - Marriage certificate for Don and Debby Kerr
   - Relationship details between Donna Mowry and George Richard Mowry
   - Information about Norman William "Bud" Lowe's life and background
   - Relationship of Conny/Connie, Bruce, Georgia Newman, and Dean to the family

3. **Extended Family Gaps:**
   - More details about Steve Kerr's marriages and children
   - Information about Sharron Kerr's marriages and child
   - Details about Vanessa Kerr Otsuka's family

## Sources
- Personal knowledge shared by Jeff Kerr (May 13, 2025)
- Family records and research documents provided in uploaded files
- Census, marriage, military, and death records mentioned in research documents