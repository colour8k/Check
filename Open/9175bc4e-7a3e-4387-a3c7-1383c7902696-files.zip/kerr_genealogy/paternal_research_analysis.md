# Paternal Family Research Analysis

## Overview of Paternal Lineage

The paternal side of the Kerr family centers around Don Kerr (born December 8, circa 1950), father of Jeff and Linsey Kerr. Through detailed examination of the genealogical documents, we can establish a clear picture of the paternal lineage, key relationships, and connections to the local community. This research focuses particularly on the Kerr family's deep roots in southwestern Michigan and their connections to notable locations and individuals.

## Key Paternal Figures and Relationships

### Don Kerr (Father)
- Born December 8, circa 1950
- Likely born in Three Rivers or Sturgis, Michigan
- Married to Debby Kerr (née Mowry)
- Father of Jeff Kerr (born August 6, 1977) and Linsey Kerr (born December 13, year unknown)
- Currently resides in the family home on Jefferson Road, Otsego, Michigan (previously owned by his mother-in-law)

### Donald Kerr (Paternal Grandfather)
- Birth and death dates unknown
- Likely resided in the Three Rivers or Sturgis area of St. Joseph County, Michigan
- Married to Loraine Kerr
- Father of four children: Don, Steve, Vanessa, and Sharron
- Possibly served as a paratrooper, likely during World War II
- May have connections to Kerr Creek Road in the Three Rivers area, suggesting significant family presence in the region

### Loraine Kerr (Paternal Grandmother)
- Maiden name unknown
- Birth and death dates unknown
- Likely resided in the Three Rivers or Sturgis area
- Mother of four children: Don, Steve, Vanessa, and Sharron

### Paternal Aunts and Uncles

#### Steve Kerr (Paternal Uncle)
- Recently deceased overseas in a tropical location
- Younger than Don Kerr
- Had two marriages:
  - First marriage (wife's name unknown) produced two children: Jeremy and Heather
  - Second marriage to Debby Kerr (currently in Kalamazoo) produced two children: Daniel and Ryan

#### Vanessa Kerr Otsuka (Paternal Aunt)
- Currently lives in California
- Married to Richard Otsuka
- Mother of Evan and Bobby Otsuka (both noted to have played sports)
- Stepmother to Richard's daughter from a previous relationship

#### Sharron Kerr (Paternal Aunt, Deceased)
- Died young (date unknown)
- Had two marriages:
  - First marriage to Tom Decker
  - Second marriage to Dick Grimms, which produced one child: Carey Grimms

## Geographic Significance and Local Connections

### Kerr Creek Road
The most significant geographic connection to the Kerr family is Kerr Creek Road in the Three Rivers/Sturgis area of St. Joseph County, Michigan. The naming of this road indicates:

1. **Substantial Early Presence**: Roads in rural Michigan were typically named after families who:
   - Owned significant land along the route
   - Were early or prominent settlers in the specific area
   - Made notable contributions to local development

2. **Historical Significance**: The existence of Kerr Creek Road provides compelling evidence that the Kerr family had established a significant presence in the Three Rivers/Sturgis area, likely by the late 19th or early 20th century.

3. **Kerr Creek**: Associated with the road, there is likely an actual waterway named Kerr Creek, suggesting the family owned land through which the creek flowed.

These geographic connections cement the family's historical ties to the physical landscape of southwestern Michigan and suggest potentially significant land ownership in the area.

## Military Connections

The Kerr family has a documented tradition of military service:

### Donald Kerr (Paternal Grandfather)
- Served as a paratrooper, likely during World War II
- This represented service in an elite military unit requiring specialized training
- WWII paratroopers played crucial roles in major battles and operations
- This service may have been recognized by local veterans' organizations or memorials

This military connection not only represents personal service but also potential integration into veterans' organizations and military commemoration events in the Three Rivers/Sturgis community.

## Family Distribution and Movement

### Geographic Centers
The Kerr family has two main geographic centers:

1. **Three Rivers/Sturgis Area (St. Joseph County)**:
   - Original Kerr family center
   - Location of Kerr Creek Road
   - Currently home to Heather Kerr (daughter of Steve Kerr)

2. **Otsego/Plainwell Area (Allegan County)**:
   - Location of Jefferson Road home (maternal family center)
   - Where Don and Debby Kerr raised their family
   - About 40 miles north of the Three Rivers area

### Current Family Distribution
The extended Kerr family now spans multiple locations:

- **Michigan**:
  - Grand Rapids: Jeff Kerr
  - Detroit: Daniel Kerr (son of Steve)
  - Kalamazoo: Ryan Kerr and his mother Debby (Steve's second wife)
  - Three Rivers/Sturgis: Heather Kerr (daughter of Steve)

- **Out of State**:
  - California: Vanessa Kerr Otsuka and family (Evan and Bobby Otsuka)
  - Louisiana: Jeremy Kerr (son of Steve)

This distribution shows both geographical rootedness in southwestern Michigan and expansion to other states, reflecting typical American family migration patterns of the late 20th century.

## Notable Paternal Family Events

- **1940s**: Likely marriage of Donald and Loraine Kerr
- **December 8, circa 1950**: Birth of Don Kerr
- **Late 20th Century**: Marriages of Don's siblings (Steve, Vanessa, Sharron)
- **Unknown Date**: Death of Sharron Kerr at a young age
- **Recent (before May 2025)**: Death of Steve Kerr overseas

## "Cool Facts" About the Paternal Line

1. **Geographic Legacy**: The Kerr family name is literally on the map in southwestern Michigan through Kerr Creek Road, representing a lasting impact on the local geography.

2. **Military Heritage**: Donald Kerr's service as a paratrooper represents participation in one of the most elite and dangerous military assignments, requiring specialized training and exceptional courage.

3. **Family Expansion**: From a core center in southwestern Michigan, the Kerr family has expanded to both coasts (Michigan to California) and the South (Louisiana), representing the geographic mobility of American families.

4. **Athletic Connections**: The Kerr family has athletic participation across generations, with Evan and Bobby Otsuka (Vanessa's sons) noted as having played sports.

5. **Multi-Generational Michigan Presence**: Despite geographic expansion, the family maintains a strong presence in Michigan across multiple generations, with family members in Grand Rapids, Kalamazoo, Detroit, and the Three Rivers/Sturgis area.

6. **Entrepreneurial Potential**: Given the naming of Kerr Creek Road and the family's established presence in the area, earlier generations may have been involved in agriculture, business, or other entrepreneurial endeavors significant enough to have a road named after them.

7. **Family Size Consistency**: Both Donald and Loraine Kerr had four children, and their son Don continued the pattern of having multiple children, showing a consistent family structure across generations.

8. **Diverse Marriage Patterns**: The family demonstrates diverse marriage patterns, with some marriages lasting decades while others (like those of Sharron Kerr) ended and were followed by remarriage, reflecting changing American marriage patterns over time.

## Research Gaps and Opportunities

Several aspects of the paternal family history remain to be fully documented:

1. **Birth and Death Records**: Finding birth and death records for Donald and Loraine Kerr would provide crucial information about their lives and origins.

2. **Marriage Certificate**: Locating the marriage certificate for Donald and Loraine Kerr would establish when they formed their family.

3. **Loraine's Maiden Name**: Discovering Loraine Kerr's maiden name would open research opportunities into her family line.

4. **Sharron's Early Death**: Learning more about the circumstances of Sharron Kerr's early death would complete an important chapter in the family history.

5. **Military Records**: Obtaining military service records for Donald Kerr would provide details about his service as a paratrooper.

6. **Property Records**: Researching property records in St. Joseph County could illuminate the connection between the Kerr family and Kerr Creek Road.

7. **Local Newspapers**: Searching newspapers from the Three Rivers and Sturgis area might reveal mentions of the Kerr family and their local activities and contributions.

## Connection to Diana and Bill Cole

Based on the request to find connections between the user's parents (Don and Debby Kerr) and Diana and Bill Cole, several possibilities emerge, though direct documentation is not present in the reviewed files:

1. **Social Connections**: The Coles may have been friends or social acquaintances of Don and Debby Kerr in the Otsego/Plainwell area.

2. **Work Relationships**: They might have been connected through professional or work relationships.

3. **Community Organizations**: The families may have participated in the same community organizations, church groups, or local activities.

4. **Children's Activities**: If the Cole family had children of similar age to Jeff and Linsey, the families might have connected through school or children's activities.

5. **Extended Family Connection**: The Coles might be related to either the Kerr or Mowry families through a branch not fully documented in the current records.

Further research into local community records, newspapers, organizational memberships, and direct family interviews would be needed to establish the exact nature of the connection between the Kerrs and the Coles.

## Conclusion

The paternal side of the Kerr family presents a fascinating study in geographic rootedness combined with modern mobility. With deep roots in southwestern Michigan evidenced by Kerr Creek Road, the family has maintained a significant presence in the state while also expanding to other regions of the country. The military service of Donald Kerr adds a dimension of national service to the family history, while the various marriages and family formations demonstrate the evolution of American family structures throughout the 20th century.

The research conducted provides a solid foundation for understanding the paternal lineage, though significant opportunities remain to fill gaps in the family history and discover more about the Kerrs' connections to their communities and to other families like the Coles. The paternal history, with its geographic landmarks and multi-generational presence in Michigan, forms a crucial part of Jeff Kerr's family heritage and identity.