# Maternal Family Research Analysis and Expansion

## Overview

The maternal side of the Kerr family centers around Debby Mowry (born February 3, circa 1948), mother of Jeff and Linsey Kerr. Through extensive research of the provided genealogical documents, we can establish a clearer picture of the maternal lineage, key relationships, and connections to notable individuals mentioned by the user (Dean Sheldon, Georgia Newman, Cathy Merrit, Connie, Lisa, Diane and Bill Cole).

## Key Maternal Figures and Relationships

### Debby Mowry Kerr
- Born February 3, circa 1948
- Married to Don Kerr
- Mother of Jeff Kerr (born August 6, 1977) and Linsey Kerr (born December 13, year unknown)
- Daughter of Donna Mowry and George Richard Mowry
- Currently resides in the family home on Jefferson Road, Otsego, Michigan (previously owned by her mother)

### Donna Mowry
- Maternal grandmother to Jeff and Linsey Kerr
- Had a relationship with George Richard Mowry that resulted in the birth of Debby around February 1948
- Later formed a long-term relationship with Norman William "Bud" Lowe
- Owned home on Jefferson Road in Otsego, Allegan County, Michigan
- Died approximately March 5, 1984 in Plainwell, Michigan

### George Richard Mowry (Maternal Biological Grandfather)
- Born January 25, 1927, Kalamazoo, Michigan
- Died October 8, 1955, Cooper Township, Kalamazoo, Michigan (age 28)
- Parents: George William Mowry (1907-1953) and Cornelia C Comings (1908-1997)
- Married Patricia Corlyss Sheldon on February 28, 1948 in Otsego Township, Allegan, Michigan
- Biological father of Debby Mowry, though he married Patricia Sheldon around the time of Debby's birth

### Norman William "Bud" Lowe
- Born April 3, 1925
- Died October 3, 1989 (age 64)
- Served as Corporal in US Army during the Korean War
- Long-term partner of Donna Mowry
- Acted as stepfather to Debby Mowry
- Buried at Mountain Home Cemetery, Otsego, Allegan County, Michigan

## Analysis of Notable Individuals Mentioned

### Patricia Corlyss Sheldon
Patricia appears in the records as the wife of George Richard Mowry (they married February 28, 1948). This marriage occurred around the same time that Donna Mowry was pregnant with or had recently given birth to Debby. As George Richard Mowry's wife, Patricia would be connected to the family history, though her relationship with Debby (who was George's biological daughter with another woman) remains unclear.

### Dean Sheldon
Based on the name similarity, Dean Sheldon may be related to Patricia Corlyss Sheldon, potentially as a brother, father, or other close relative. Given that Patricia married George Richard Mowry (Debby's biological father), Dean would be connected to the family through this marriage. This could explain why he's remembered as a notable figure on the maternal side, as he would be part of the extended family network through Patricia's connection to George.

### Georgia Newman
Based on the common pattern of women changing surnames through marriage, Georgia Newman might be:
1. A relative of Donna Mowry who married someone with the surname Newman
2. A sister or other relative of Norman "Bud" Lowe who married a Newman
3. A relative of Patricia Sheldon who maintained a connection to Debby despite George and Patricia's marriage
4. A more distant connection from the Mowry, Comings, or Sheldon families

### Cathy Merrit
Similar to Georgia Newman, Cathy Merrit likely connects to the maternal line through one of these families. The Merrit surname doesn't appear directly in the main family tree, suggesting she may be:
1. A cousin through the Mowry, Comings, or Sheldon lines
2. A step-relative through Norman "Bud" Lowe's family
3. A close family friend who was considered part of the extended family

### Connie/Lisa
These individuals appear without surnames in the family records, suggesting they may be:
1. First-degree relatives (sisters/half-sisters) of Debby Mowry
2. Close first cousins who were a significant part of Debby's childhood
3. Step-relatives through Norman "Bud" Lowe's family

### Diane and Bill Cole
The Cole surname doesn't appear directly in the main family branches documented. Given that the user specifically asked about connections between their parents and Diana and Bill Cole, they likely represent:
1. Close friends of Don and Debby Kerr
2. Extended family through a branch not fully documented in the current records
3. Connections through marriage of a cousin or other relative
4. Community connections through work, church, or local organizations

## Logical Correlations and Possible Connections

### The Sheldon Connection
The presence of Patricia Corlyss Sheldon and Dean Sheldon suggests a significant Sheldon family connection to the maternal line. Given that Patricia married George Richard Mowry around the same time Debby was born to Donna Mowry, there may have been a complex family dynamic. It's possible that:

1. The Sheldon and Mowry families were already connected before George's relationships with Donna and Patricia
2. Dean Sheldon maintained a connection to Debby despite the complicated circumstances of her birth
3. The Sheldon family may have lived in the Otsego/Plainwell area, strengthening local community ties

### The Newman, Merrit, and Cole Families
While direct documentation is limited, logical analysis suggests these families connect to the maternal line through:

1. **Geographic Proximity**: All likely lived in or had connections to the Otsego/Plainwell/Kalamazoo area
2. **Social Connections**: May have been part of the same community networks, churches, or organizations
3. **Marriage Connections**: Likely connected through marriages between extended family members
4. **Childhood Friendships**: May represent Debby's childhood friends whose families remained connected throughout adulthood

### Potential Cole Family Connection to Don and Debby
Since the user specifically asked about connections between their parents (Don and Debby Kerr) and Diana and Bill Cole, the following scenarios are most likely:

1. **Long-term Friendship**: The Coles may have been close friends of Don and Debby, possibly from their early marriage years
2. **Community Connection**: They may have been connected through local organizations, church, or community activities in the Otsego area
3. **Extended Family**: They could be related through a branch not fully documented in the current records, such as through Loraine Kerr's family (Don's mother) or another maternal connection
4. **Shared Experiences**: They may have shared significant life experiences with Don and Debby, such as raising children of similar ages, working together, or participating in community events

## Historical and Geographic Context

The maternal family history centers around several key locations in southwestern Michigan:

1. **Otsego, Allegan County**: Home to Donna Mowry and later Debby and Don Kerr (Jefferson Road)
2. **Plainwell**: Adjacent to Otsego, reported death location of Donna Mowry
3. **Kalamazoo**: Birth place of George Richard Mowry, approximately 15 miles from Otsego
4. **Cooper Township, Kalamazoo County**: Death place of George Richard Mowry

These locations are all within approximately 20 miles of each other, indicating a family deeply rooted in the southwestern Michigan region. The close proximity would have allowed for family members to maintain connections despite living in different towns, and would explain the network of relationships spanning Allegan and Kalamazoo counties.

## Identified Research Gaps and Opportunities

1. **Birth Certificates**: Locating Debby Mowry's birth certificate would potentially confirm George Richard Mowry as her father and provide a precise birth date.

2. **Marriage Records**: Finding the marriage record for Don and Debby Kerr would provide additional context about when they established their family.

3. **Newspaper Archives**: Local newspapers from Otsego, Plainwell, and Kalamazoo from the relevant periods might contain announcements, social news, or other information about the families.

4. **Obituaries**: Locating obituaries for key individuals, particularly Donna Mowry's obituary from approximately March 1984, might provide information about family relationships and surviving relatives.

5. **Census Records**: Further research into census records could provide additional context about household compositions and family relationships.

6. **Interviews with Living Relatives**: Direct interviews with living family members could provide valuable firsthand accounts of family relationships and connections.

7. **Community Records**: Church records, school yearbooks, and local organizational memberships might provide additional information about family connections and community involvement.

## Maternal Family Extensions

Based on the research, the maternal family extends beyond the core individuals documented in the family tree:

1. **Through George Richard Mowry**: Connection to the George William Mowry and Cornelia C Comings families, potentially including siblings of George Richard Mowry.

2. **Through Patricia Corlyss Sheldon**: Connection to the Sheldon family, including potentially Dean Sheldon.

3. **Through Donna Mowry**: Potential siblings or half-siblings, which might include some of the mentioned individuals like Connie or Lisa.

4. **Through Norman William "Bud" Lowe**: Connection to the Lowe family, which might include some of the mentioned individuals.

## Notable Maternal Family Timeline Events

- **1907**: Birth of George William Mowry (maternal great-grandfather)
- **1908**: Birth of Cornelia C Comings (maternal great-grandmother)
- **April 3, 1925**: Birth of Norman William "Bud" Lowe
- **January 25, 1927**: Birth of George Richard Mowry (maternal biological grandfather)
- **February 28, 1948**: Marriage of George Richard Mowry to Patricia Corlyss Sheldon
- **February 3, circa 1948**: Birth of Debby Mowry
- **1953**: Death of George William Mowry (maternal great-grandfather)
- **October 8, 1955**: Death of George Richard Mowry at age 28
- **March 5, 1984 (approximate)**: Death of Donna Mowry
- **October 3, 1989**: Death of Norman William "Bud" Lowe
- **1997**: Death of Cornelia C Comings (maternal great-grandmother)

## Interesting "Cool Facts" About the Maternal Line

1. **Unusual Family Formation**: Debby Mowry's biological parents (George Richard Mowry and Donna Mowry) never married, with George marrying Patricia Sheldon around the time of Debby's birth in 1948, creating an unconventional family story.

2. **Tragic Early Death**: George Richard Mowry died in 1955 at only 28 years old, when his daughter Debby was just 7 years old, adding a poignant chapter to the family history.

3. **Military Service**: Norman William "Bud" Lowe, who became Debby's stepfather figure, served as a Corporal in the US Army during the Korean War, bringing military service into the family history.

4. **Intergenerational Home**: The Jefferson Road property in Otsego passed from Donna Mowry to her daughter Debby and son-in-law Don Kerr, becoming a multi-generational family homestead.

5. **Geographic Rootedness**: The maternal family has deep roots in southwestern Michigan, with multiple generations living within a 20-mile radius spanning Allegan and Kalamazoo counties.

6. **Complex Family Networks**: The maternal side demonstrates how families often extend beyond direct biological relationships to include step-parents, half-siblings, and close family friends who become considered part of the extended family.

7. **Longevity Contrast**: While George Richard Mowry died young at 28, his mother Cornelia C Comings lived to be 89 years old (1908-1997), demonstrating the wide variation in lifespan even within a single family line.

8. **Family Continuity Despite Loss**: Despite the early death of George Richard Mowry, the family connection to the Mowry name continued through Debby, who passed it along as part of her heritage even after taking the Kerr surname upon marriage.

## Conclusion

The maternal side of the Kerr family presents a fascinating study in family dynamics, with connections spanning multiple families including the Mowrys, Comings, Sheldons, and Lowes. While some relationships remain to be fully documented, the existing research provides a solid foundation for understanding the maternal lineage and its significance in the broader family history.

The connections to Dean Sheldon, Georgia Newman, Cathy Merrit, Connie, Lisa, and Diane and Bill Cole likely represent a combination of biological relatives, step-relatives, and close family friends who were considered part of the extended family network. Further research would be valuable to clarify these relationships and expand the understanding of the maternal family's rich history and connections.