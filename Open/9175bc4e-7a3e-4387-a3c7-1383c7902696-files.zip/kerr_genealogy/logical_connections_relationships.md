# Logical Connections and Relationships in the Kerr Family History

## Introduction

After a thorough examination of the extensive genealogical materials on the Kerr family, this analysis focuses on making logical correlations between various family members, identifying relationships between mentioned notable individuals, and establishing connections between the user's parents (Don and Debby Kerr) and Diana and Bill Cole. While some of these connections are not explicitly documented in the existing materials, logical deductions and contextual analysis allow us to propose likely relationships and connections.

## Connection Between the User's Parents and Diana & Bill Cole

The user specifically requested information about connections between their parents (Don and Debby Kerr) and Diana and Bill Cole. While direct documentation of this relationship is not present in the examined files, several logical possibilities emerge:

### Possible Connection Pathways

1. **Through the Sheldon Family Connection**
   - Patricia Corlyss Sheldon married George Richard Mowry (Debby's biological father) on February 28, 1948
   - Dean Sheldon was mentioned as a notable person on the maternal side
   - If Diana Cole (possibly Diana Sheldon before marriage) is related to the Sheldon family, this would create a connection between Diana and Bill Cole and the user's parents
   - This connection would be through Debby's biological father's marriage

2. **Through the Maternal Extended Family Network**
   - Several individuals with unclear relationships were mentioned in the maternal family documents (Connie, Lisa, Georgia Newman, Cathy Merrit)
   - Diana Cole might be one of these individuals (perhaps Lisa's full name is Lisa Diana, who later married Bill Cole)
   - Alternatively, Diana might be related to Georgia Newman or Cathy Merrit
   - This would create a connection through Debby's extended family network

3. **Through the Paternal Side**
   - Loraine Kerr's maiden name is unknown
   - If Loraine's maiden name was Cole or she had close relatives who married into the Cole family, Diana and Bill could be related to Don through his mother's family
   - This would establish a paternal family connection

4. **Through Community and Social Connections**
   - Given the tight-knit nature of the communities in southwestern Michigan where the family lived (Otsego, Plainwell, Three Rivers, Sturgis)
   - The Coles and Kerrs might have been:
     - Neighbors in the Jefferson Road area of Otsego
     - Fellow church members
     - Work colleagues
     - Parents of children who were friends with Jeff and Linsey
   - These social connections often became considered "family" in close communities

5. **Through Educational Institutions**
   - Otsego Public Schools or other local educational institutions
   - Don or Debby may have been classmates, fellow teachers, or had other educational connections with Diana and Bill Cole
   - School connections often formed the basis for lifelong relationships in small communities

### Most Likely Connection Based on Available Information

Based on the emphasis on the maternal side and specifically on Dean Sheldon in the user's request, the most probable connection is through the Sheldon family. A logical hypothesis would be:

- Diana Cole (née Sheldon) is related to Patricia Corlyss Sheldon and Dean Sheldon
- Diana may be Dean's daughter or sister, or Patricia's sister
- This would create a family connection to Debby through her biological father's marriage
- Don and Debby Kerr maintained a relationship with Diana and Bill Cole despite the complex family circumstances

## Notable People Mentioned and Their Likely Relationships

### Dean Sheldon

**Logical Connection**: Most likely a close relative of Patricia Corlyss Sheldon, who married George Richard Mowry on February 28, 1948. Given naming patterns and common family structures:

- Dean might be Patricia's brother
- Alternatively, Dean could be Patricia's father
- As a Sheldon family member, Dean would be connected to Debby Mowry through her biological father's marriage
- The Sheldon family appears to have been significant in the Otsego/Allegan County area

### Georgia Newman

**Logical Connection**: Based on the name pattern (female with apparent married surname):

- Likely a relative of Donna Mowry who married someone with the surname Newman
- Could be Donna's sister, making her Debby's aunt
- Alternatively, could be a relative of Norman "Bud" Lowe
- The Newman surname suggests she maintained her own identity after marriage, which was becoming more common in the mid-to-late 20th century
- Maintained enough of a connection to be remembered as significant by the family

### Cathy Merrit

**Logical Connection**: Similar to Georgia Newman, the pattern suggests:

- A female relative who married someone with the surname Merrit
- Could be related to either Donna Mowry or Norman "Bud" Lowe
- Possibly a cousin or niece who remained close to the family
- The Merrit family may have been prominent in the Otsego/Plainwell area
- Could be connected through church, social, or community organizations

### Connie and Lisa

**Logical Connection**: The use of first names only suggests closer relationships:

- Possibly siblings or half-siblings of Debby Mowry
- Could be daughters of Donna Mowry from another relationship
- Alternatively, might be very close cousins who were considered immediate family
- The lack of surnames in family memory indicates they were likely thought of as direct family rather than extended relatives
- Their exact relationship to Donna, Norman "Bud" Lowe, or George Richard Mowry remains to be determined

## Extended Family Relationships and Connections

### The Sheldon Family Connection

The marriage of George Richard Mowry to Patricia Corlyss Sheldon on February 28, 1948, creates an important family connection that helps explain several relationships:

1. This marriage occurred around the same time that Debby Mowry was born to Donna Mowry and George Richard Mowry
2. The timing suggests a complex family situation where George had relationships with both Donna and Patricia around the same time
3. Despite this complexity, the Sheldon family appears to have maintained some connection to Debby's side of the family
4. The continued significance of Dean Sheldon in family memory indicates that these relationships transcended the potentially difficult circumstances

### The Mowry-Lowe Household Dynamic

The relationship between Donna Mowry and Norman "Bud" Lowe creates another important family dynamic:

1. After her relationship with George Richard Mowry ended, Donna formed a long-term relationship with Norman
2. Norman became a father figure to Debby despite not being her biological father
3. This blended family structure likely included or had connections to some of the individuals mentioned (Connie, Lisa, Georgia Newman, Cathy Merrit)
4. The Jefferson Road home in Otsego became a central gathering point for this extended family network
5. After Donna's death in 1984, Norman continued to be part of the family until his death in 1989

### The Cole Family Integration

While specific documentation about Diana and Bill Cole is limited, contextual analysis suggests:

1. They were significant enough in Don and Debby's lives for their son to specifically ask about them decades later
2. They likely were more than casual acquaintances, given their memorable status
3. The connection probably spans decades, possibly back to Don and Debby's early marriage or even earlier
4. They may have been present at significant family events and milestones
5. Their relationship with Don and Debby likely involved mutual support and friendship beyond casual social interaction

## Logical Timeline of Key Relationships

A proposed timeline of key relationships helps illustrate how these connections may have developed:

1. **Late 1940s**: George Richard Mowry has relationships with both Donna Mowry and Patricia Corlyss Sheldon
2. **February 1948**: Debby Mowry is born to Donna; George marries Patricia Sheldon
3. **Early 1950s**: Norman "Bud" Lowe begins relationship with Donna Mowry after returning from Korean War service
4. **1955**: George Richard Mowry dies at age 28, potentially strengthening the Sheldon family's desire to maintain connections to his daughter Debby
5. **Late 1960s/Early 1970s**: Debby Mowry meets and marries Don Kerr
6. **1970s**: Don and Debby establish connections with Diana and Bill Cole, possibly through shared community activities or through the Sheldon family connection
7. **1977-1980s**: Jeff and Linsey Kerr are born and grow up with awareness of these family connections
8. **1984**: Donna Mowry dies, potentially causing the family to strengthen connections with extended family and friends like the Coles
9. **1989**: Norman "Bud" Lowe dies, further emphasizing the importance of extended family connections

## Conclusions on Family Relationships

The Kerr family genealogy presents a complex but fascinating web of relationships that extend beyond traditional nuclear family boundaries. Key conclusions about these relationships include:

1. **Blended Family Dynamics**: The maternal side demonstrates how families adapt to complex situations, with Norman "Bud" Lowe stepping in as a father figure for Debby despite not being her biological father.

2. **Maintained Connections Despite Complexity**: The continued significance of the Sheldon family (including Dean Sheldon) suggests that families found ways to maintain important relationships despite potentially difficult circumstances.

3. **Geographic Proximity Facilitating Relationships**: The concentration of family members in southwestern Michigan (Otsego, Plainwell, Kalamazoo, Three Rivers, Sturgis) created opportunities for maintaining family connections across generations.

4. **Extended Family Integration**: Individuals like Georgia Newman, Cathy Merrit, Connie, and Lisa represent how extended family members become integral parts of the family narrative and memory.

5. **Community Connections Becoming "Family"**: The relationship with Diana and Bill Cole likely represents how close community connections often become considered "family" in small-town contexts, blurring the line between biological relatives and chosen family.

6. **Multigenerational Impact**: The fact that these relationships remain significant enough for the user to specifically inquire about them demonstrates how family connections span decades and continue to influence identity and memory across generations.

The logical connections established in this analysis provide a framework for understanding the Kerr family's rich network of relationships. While further research and documentation would be valuable to confirm these connections, the logical correlations presented here offer a compelling picture of how the various individuals mentioned fit into the broader family narrative.