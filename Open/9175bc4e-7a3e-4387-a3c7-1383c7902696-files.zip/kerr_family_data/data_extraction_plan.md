# Kerr Family Genealogy: Data Extraction and Organization Plan

## Overview
This document outlines the systematic approach for extracting, organizing, and structuring all genealogical data from the uploaded materials. The goal is to create comprehensive datasets that will serve as the foundation for both deep analysis and website development.

## Data Extraction Categories

### 1. Individual Records
- **Core Information**: Full name, birth date/place, death date/place, burial location
- **Personal Details**: Occupation, education, military service, religious affiliation
- **Residence History**: Chronological list of known residences with dates
- **Notable Facts**: Unique characteristics, achievements, anecdotes
- **Source Links**: Direct connections to source documents

### 2. Family Relationships
- **Parent-Child**: All documented parent-child relationships
- **Marriages/Partnerships**: Dates, locations, dissolution if applicable
- **Siblings**: Full and half-sibling relationships
- **Extended Relationships**: Aunts/uncles, cousins, in-laws
- **Non-Biological Relationships**: Step-relationships, adoptions, guardianships
- **Social Relationships**: Close friends, neighbors, mentors mentioned in documents

### 3. Geographic Data
- **Residence Locations**: Complete address when available, otherwise town/county/state
- **Event Locations**: Birth, marriage, death, burial locations
- **Family Centers**: Identified centers of family activity (Three Rivers/Sturgis for paternal, Otsego/Plainwell for maternal)
- **Migration Patterns**: Movement between locations with approximate dates
- **Property Ownership**: Documented land/property ownership with dates

### 4. Temporal Data
- **Individual Timelines**: Chronological events for each person
- **Family Timelines**: Overlapping events across family units
- **Generational Mapping**: Events organized by generation
- **Historical Context**: Family events mapped against local/national historical events

### 5. Documentation & Sources
- **Primary Sources**: Birth certificates, death certificates, marriage licenses
- **Secondary Sources**: Census records, obituaries, newspaper mentions
- **Family Artifacts**: Letters, photographs, documents mentioned
- **Research Notes**: Questions, uncertainties, contradictions in the data

## Data Organization Structure

### Paternal Line (Kerr)
1. **Donald & Loraine Kerr Family Unit**
   - Donald Kerr (paternal grandfather)
   - Loraine Kerr (paternal grandmother)
   - Children: Don, Steve, Vanessa, Sharron
   - Military service records for Donald
   - Kerr Creek Road connection

2. **Don & Debby Kerr Family Unit**
   - Don Kerr
   - Debby Kerr (née Mowry)
   - Children: Jeff, Linsey
   - Jefferson Road home

3. **Steve Kerr Extended Family**
   - First marriage and children: Jeremy, Heather
   - Second marriage to Debby and children: Daniel, Ryan
   - Recent death details

4. **Vanessa Kerr Otsuka Extended Family**
   - Marriage to Richard Otsuka
   - Children: Evan, Bobby
   - California connections

5. **Sharron Kerr Extended Family**
   - Marriage to Tom Decker
   - Marriage to Dick Grimms
   - Child: Carey Grimms
   - Early death circumstances

### Maternal Line (Mowry/Lowe)
1. **George William & Cornelia Comings Mowry Family Unit**
   - George William Mowry (1907-1953)
   - Cornelia C Comings (1908-1997)
   - Child: George Richard Mowry

2. **George Richard Mowry Connections**
   - Birth/death information (1927-1955)
   - Relationship with Donna Mowry
   - Marriage to Patricia Corlyss Sheldon
   - Biological father of Debby Mowry

3. **Donna Mowry & Norman "Bud" Lowe Family Unit**
   - Donna Mowry details
   - Norman William "Bud" Lowe (1925-1989)
   - Military service for Norman
   - Jefferson Road property
   - Relationship timeline

4. **Sheldon Family Connections**
   - Patricia Corlyss Sheldon
   - Dean Sheldon
   - Other Sheldon family members
   - Connection to Diana (potentially née Sheldon) and Bill Cole

5. **Other Maternal Connections**
   - Georgia Newman
   - Cathy Merrit
   - Connie/Lisa
   - Additional mentioned individuals

### Cross-Family Connections
1. **Jefferson Road Property**
   - Ownership timeline
   - Transfer from Donna Mowry to Don/Debby Kerr
   - Significance as family center

2. **Don & Debby Kerr to Diana & Bill Cole**
   - Documented or likely connection pathways
   - Potential relationship through Sheldon family
   - Social/community connection possibilities

3. **FAN Club Connections**
   - Friends, associates, and neighbors appearing in multiple contexts
   - Witnesses at important events
   - Recurring names across documents

## Implementation Strategy

### Step 1: Create Standardized Individual Profiles
- Template with consistent fields for all identified individuals
- Uncertainty indicators for estimated dates or relationships
- Citation connections to source documents
- Unique ID for each individual for relationship mapping

### Step 2: Develop Relationship Database
- Structured format documenting all known relationships
- Connection types (biological, legal, social)
- Duration of relationships
- Source evidence for each connection

### Step 3: Build Geographic and Temporal Datasets
- Location database with standardized place names
- Timeline database with date ranges and certainty indicators
- Event categorization system
- Family center identification and mapping

### Step 4: Identify Information Gaps
- Systematic documentation of missing information
- Prioritization of research gaps
- Confidence ratings for existing information
- Contradiction or conflict identification

### Step 5: Prepare Data for Analysis and Website Integration
- Export formats suitable for visualization tools
- Structured data for website integration
- Documentation of data structure and relationships
- Version control system for ongoing updates

## Output Documents

1. **Individual Profiles Collection**
   - Complete structured profiles for all identified individuals
   - Standardized format for easy comparison and analysis

2. **Family Relationship Network**
   - Structured documentation of all family relationships
   - Connection mapping for visualization

3. **Geographic and Temporal Datasets**
   - Locations database with standardized formatting
   - Chronological events database with relationships to individuals

4. **Research Gaps Analysis**
   - Prioritized list of missing information
   - Suggestions for further research sources

5. **Analytical Framework Preparation**
   - Dataset prepared for pattern analysis
   - Structure for identifying correlations and coincidences
   - Foundation for website information architecture