# Unique Family Relationships and Dynamics

## Complex Family Formations

### The Donna Mowry - George Richard Mowry - Norman "Bud" Lowe Triangle
One of the most complex and interesting family structures centers around Debby Mowry's childhood and parentage:

1. **Biological Connection**
   - George Richard Mowry (1927-1955) was Debby's biological father
   - Donna Mowry was Debby's mother
   - Their relationship appears to have been brief or complicated

2. **Timeline of Complexity**
   - Debby was born around February 1948
   - George Richard Mowry married Patricia Corlyss Sheldon on February 28, 1948 (the same month as Debby's birth)
   - This timing suggests George may have had overlapping relationships or that his relationship with Donna ended during her pregnancy

3. **Chosen Family Formation**
   - Norman William "Bud" Lowe (1925-1989) became Donna's long-term partner
   - Despite no biological connection, Norman became a father figure to Debby
   - This relationship likely formed after George's marriage to Patricia, possibly after his Korean War service

4. **Impact on Family Identity**
   - Debby grew up with Norman as her father figure rather than her biological father
   - George Richard Mowry died in 1955 when Debby was only about 7 years old
   - Norman's role as "chosen father" demonstrates how family bonds extend beyond biology
   - The Jefferson Road home became the physical center of this non-traditional family unit

### Steve Kerr's Blended Family
Another complex family formation appears in Steve Kerr's life:

1. **Multiple Marriage Pattern**
   - First marriage to unknown woman produced two children (Jeremy and Heather)
   - Second marriage to another woman named Debby Kerr produced two more children (Daniel and Ryan)
   - Created half-sibling relationships across marriages

2. **Geographic Dispersion**
   - Children from first marriage: Jeremy moved to Louisiana, Heather stayed in Michigan
   - Children from second marriage: Daniel moved to Detroit, Ryan stayed in Kalamazoo
   - Second wife Debby and son Ryan currently live in Kalamazoo

3. **Maintenance of Family Connections**
   - Research question: How do these half-siblings maintain relationships across geographic distance?
   - How did the name "Debby" appearing in both generations (Steve's sister-in-law and second wife share the name) affect family dynamics?

### Sharron Kerr's Family Pattern
Sharron Kerr's early death created another unique family structure:

1. **Multiple Marriage Pattern**
   - First marriage to Tom Decker (no known children mentioned)
   - Second marriage to Dick Grimms produced one child (Carey Grimms)
   - Early death left Carey potentially being raised by father alone

2. **Research Questions**
   - How did Sharron's early death affect her child's connection to the Kerr family?
   - Did the Kerr grandparents (Donald and Loraine) maintain a relationship with Carey Grimms?
   - What role did Tom Decker (first husband) play, if any, in the family after the end of the marriage?

### Vanessa Kerr Otsuka's Blended Family
Vanessa's marriage created a multicultural blended family:

1. **Intercultural Marriage**
   - Marriage between Vanessa Kerr and Richard Otsuka represents cultural blending
   - Suggests potential mixing of Midwestern and Japanese-American traditions

2. **Blended Family Structure**
   - Richard brought a daughter from a previous relationship
   - Together they had two sons (Evan and Bobby)
   - Created step-sibling and half-sibling relationships

3. **Research Questions**
   - How did this multicultural blended family navigate cultural traditions?
   - What relationship exists between Richard's daughter and his sons with Vanessa?
   - How are connections maintained with the Michigan-based Kerr relatives?

## Non-Traditional Parenting Arrangements

### Norman "Bud" Lowe as Chosen Father
The most significant non-biological parenting relationship appears between Norman Lowe and Debby Mowry:

1. **Formation of Relationship**
   - Norman entered Debby's life after her biological father was no longer present
   - He served as the consistent father figure through her childhood
   - This relationship likely influenced Debby's understanding of family

2. **Legal Status Questions**
   - Did Norman legally adopt Debby?
   - If not formally adopted, what legal arrangements existed regarding guardianship?
   - How was Norman identified on Debby's marriage certificate or other legal documents?

3. **Family Recognition**
   - Norman appears to have been fully recognized as Debby's father figure by the family
   - Jeff Kerr knew Norman as his maternal grandfather figure
   - The relationship transcended biological connections to create genuine family bonds

4. **Legacy of Relationship**
   - Norman's example demonstrates the importance of chosen family relationships
   - His role shows how step-parents can become primary parental figures
   - The multi-generational impact continued through Debby's children knowing Norman as "grandfather"

### Multi-Generational Impact of Jefferson Road Home
The Jefferson Road property represents another unique aspect of family formation:

1. **Property Transfer Pattern**
   - Owned by Donna Mowry
   - Transferred to daughter Debby and son-in-law Don Kerr
   - Became childhood home of Jeff and Linsey Kerr
   - Represents physical continuity across three generations

2. **Significance as Family Center**
   - Provided stability during complex family transitions
   - Served as consistent geographic anchor for maternal line
   - Created sense of place and belonging across generations

3. **Research Questions**
   - When and how was the property transferred from Donna to Debby and Don?
   - What memories and associations does the Jefferson Road home hold for family members?
   - Are there specific features or spaces in the home that held special significance?

## Unusual Age and Relationship Patterns

### Early Death of George Richard Mowry
The early death of George Richard Mowry created a significant pattern:

1. **Timeline Impact**
   - Died in 1955 at just 28 years old
   - His daughter Debby was only about 7 years old
   - Created absence of biological father throughout most of Debby's childhood
   - May have influenced Norman Lowe's entry into the family

2. **Intergenerational Pattern**
   - George Richard Mowry died young (28)
   - His father George William Mowry also died relatively young (46 in 1953)
   - Both father and son died within two years of each other
   - Created double loss for Cornelia Comings (lost both husband and son)

3. **Effect on Family Knowledge**
   - Early deaths likely limited the transmission of family stories and history
   - Debby would have had few personal memories of her biological father
   - May explain some gaps in knowledge about the Mowry family history

### Contrasting Longevity in Maternal Line
While some family members died young, others showed remarkable longevity:

1. **Cornelia C Comings (1908-1997)**
   - Lived to 89 years old
   - Survived both husband and son by decades
   - May have been an important link to family history for later generations

2. **Research Questions**
   - Did Cornelia maintain a relationship with her granddaughter Debby?
   - What role did she play in preserving family history after the deaths of her husband and son?
   - Are there other examples of notable longevity in the family?

### Early Death of Sharron Kerr
Similar to George Richard Mowry, Sharron Kerr's early death created another unusual pattern:

1. **Impact on Family Structure**
   - Created potential for loss of connection to that branch
   - Siblings (Don, Steve, Vanessa) became more important for maintaining family continuity
   - Child (Carey Grimms) potentially raised with limited Kerr family influence

2. **Research Questions**
   - How old was Sharron when she died?
   - What was the cause of her early death?
   - How did her death affect her siblings and parents?

## Name Patterns and Coincidences

### Recurring Name "Debby/Debbie"
The name Debby/Debbie appears multiple times in the family:

1. **Debby Mowry Kerr** - Mother of Jeff and Linsey, daughter of Donna Mowry
2. **Debby Kerr** - Second wife of Steve Kerr (Don's brother)

This creates an unusual situation where Steve Kerr married someone with the same name as his sister-in-law, potentially causing confusion in family discussions or records.

### Usage of "Richard" as Middle Name
The name Richard appears significantly in the family:

1. **George Richard Mowry** - Debby's biological father
2. **Richard Otsuka** - Vanessa Kerr's husband

This could be coincidental or might suggest some pattern of naming or honoring across family branches.

### Given Name vs. Nickname Pattern
Several family members are known by nicknames rather than their full given names:

1. **Norman William "Bud" Lowe** - Known as "Bud" throughout the family
2. **Potentially others with nicknames not yet identified**

This pattern of using nicknames was common in mid-20th century America but can create challenges for genealogical research.

## Multi-Location Families

### Split Family Units
Several family units maintain connections across significant geographic distances:

1. **Steve Kerr's Children**
   - Split between Louisiana, Detroit, and Kalamazoo
   - Represent one nuclear family dispersed across multiple states

2. **Don & Vanessa Kerr Siblings**
   - Michigan and California
   - Maintained sibling relationship despite coast-to-coast separation

3. **Research Questions**
   - How often did these geographically dispersed family members see each other?
   - Were there regular reunions or gatherings?
   - How has technology affected the maintenance of these long-distance family bonds?

### Regional Loyalty vs. Geographic Mobility
The family demonstrates both regional rootedness and significant mobility:

1. **Rooted Branches**
   - Don Kerr stayed in Michigan, specifically in Otsego on property with maternal family connections
   - Heather Kerr remained in the Three Rivers/Sturgis area, close to paternal family origins

2. **Mobile Branches**
   - Vanessa moved to California
   - Jeremy moved to Louisiana
   - Daniel moved to Detroit (different region of Michigan)
   - Steve traveled internationally at some point

3. **Research Questions**
   - What factors influenced decisions to stay or leave?
   - How has geographic distance affected family traditions and knowledge transmission?
   - Are there patterns to which family members tend to stay in the home region versus those who leave?

## Multigenerational Household Patterns

### Jefferson Road Multi-Generational Connection
While not necessarily a multi-generational household in the traditional sense, the Jefferson Road property represents a multi-generational connection:

1. **Generational Occupation**
   - First occupied by Donna Mowry (and Norman "Bud" Lowe)
   - Then transferred to Debby and Don Kerr
   - Became childhood home of Jeff and Linsey Kerr

2. **Property as Family Continuity**
   - Physical space providing connection across generations
   - Potential repository of family memories and artifacts
   - Symbol of maternal line's presence in Otsego

3. **Research Questions**
   - Were there periods when three generations lived in the home simultaneously?
   - How was the property modified or maintained across generations?
   - What emotional significance does the property hold for different family members?

### Ryan Kerr Living with Mother in Kalamazoo
A current example of extended family living appears with Ryan Kerr:

1. **Current Living Arrangement**
   - Ryan Kerr lives with his mother Debby Kerr in Kalamazoo
   - Represents adult child-parent household
   - May be temporary or more permanent arrangement

2. **Research Questions**
   - Is this arrangement due to economic factors, caregiving, or preference?
   - How common is this pattern in the broader Kerr family?
   - Are there historical examples of similar arrangements in earlier generations?

## Memorial and Remembrance Patterns

### Maintained Connection to Norman "Bud" Lowe
Despite no biological connection, Norman "Bud" Lowe is remembered as an important family figure:

1. **Memory Preservation**
   - Norman is specifically remembered as Donna's partner and Debby's father figure
   - His nickname "Bud" has been preserved in family memory
   - His burial at Mountain Home Cemetery in Otsego creates physical memorial

2. **Recognition of Chosen Family**
   - Family history acknowledges and values his role despite no biological connection
   - Demonstrates how family bonds can transcend biological relationships
   - Creates more complex but richer family narrative

### Uncertain Status of Biological Connections
In contrast, some biological connections appear less prominent in family memory:

1. **George Richard Mowry**
   - Though Debby's biological father, his role in family narrative appears less developed
   - His early death and apparent absence from Debby's life may have contributed to this
   - Research question: How was his existence explained to Debby and later generations?

2. **Research Questions About Memory Patterns**
   - Which ancestors are most prominently remembered in family stories?
   - How does the family tend to memorialize or honor deceased members?
   - Are there family traditions around remembrance (visiting graves, keeping photographs, sharing stories)?

## Conclusion: The Rich Tapestry of Kerr Family Relationships

The Kerr family history demonstrates how families are formed not just through biology but through choice, circumstance, and commitment. The complex relationships identified—particularly Norman "Bud" Lowe's role as chosen father to Debby, and the maintenance of family connections across significant geographic distances—reveal a family that adapted to circumstances while maintaining meaningful bonds.

These unique family dynamics provide rich material for both genealogical research and storytelling. Understanding these complex relationships allows for a more nuanced and accurate portrayal of the family history, honoring both biological connections and the equally important chosen relationships that shaped the family identity across generations.

Each of these unique patterns offers opportunities for deeper exploration, potentially revealing insights about family values, adaptability, and resilience over time. The non-traditional aspects of the family history don't diminish its significance—rather, they enhance our understanding of how real families navigate complex circumstances while maintaining meaningful connections.