# Core Family Members

## Jeff Kerr (Primary Family Member)
- **Full Name:** Jeff Kerr
- **Birth:** August 6, 1977
- **Birth Place:** Likely Otsego, Michigan
- **Current Residence:** Grand Rapids, Michigan
- **Parents:** Don Kerr and Debby Kerr (née Mowry)
- **Sibling:** Linsey Kerr
- **Children:**
  - Jude Kerr (mother: Melissa Smith)
  - Lincon Kerr (mother: Melissa Smith)
- **Notable Facts:** Initiated the Kerr Family Genealogy Project

## Linsey Kerr (Sister)
- **Full Name:** Linsey Kerr
- **Birth:** December 13 (year unknown)
- **Parents:** Don Kerr and Debby Kerr (née Mowry)
- **Sibling:** Jeff Kerr (brother)

## Don Kerr (Father)
- **Full Name:** Don Kerr
- **Birth:** December 8, circa 1950
- **Birth Place:** Either Three Rivers or Sturgis, Michigan
- **Residence:** Jefferson Road, Otsego, Michigan (family home purchased from Debby's mother)
- **Parents:** Donald Kerr and Loraine Kerr
- **Spouse:** Debby Kerr (née Mowry)
- **Children:**
  - Jeff Kerr (born August 6, 1977)
  - Linsey Kerr (born December 13, year unknown)
- **Siblings:**
  - Steve Kerr (younger brother, recently deceased overseas)
  - Vanessa Kerr Otsuka (sister, lives in California)
  - Sharron Kerr (sister, deceased at a young age)
- **Notable Connection:** Relationship with Diana and Bill Cole (nature of connection requires further research)

## Debby Kerr (née Mowry) (Mother)
- **Full Name:** Debby Kerr (née Mowry)
- **Birth:** February 3, circa 1948
- **Birth Place:** Likely Otsego, Michigan
- **Residence:** Jefferson Road, Otsego, Michigan (family home purchased from her mother)
- **Parents:**
  - Biological Father: George Richard Mowry (1927-1955)
  - Mother: Donna Mowry
  - Mother's Partner: Norman William "Bud" Lowe
- **Spouse:** Don Kerr
- **Children:**
  - Jeff Kerr (born August 6, 1977)
  - Linsey Kerr (born December 13, year unknown)
- **Property Connection:** Current owner of Jefferson Road home that previously belonged to her mother, Donna Mowry
- **Notable Connection:** Relationship with Diana and Bill Cole (nature of connection requires further research)