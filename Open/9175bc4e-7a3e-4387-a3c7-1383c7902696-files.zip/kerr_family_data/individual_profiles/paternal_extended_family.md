# Paternal Extended Family

## Paternal Aunts and Uncles

### Steve Kerr (Paternal Uncle)
- **Full Name:** Steve Kerr
- **Birth:** Unknown (younger than Don Kerr)
- **Death:** Recently deceased overseas in tropical location
- **Parents:** Donald and Loraine Kerr
- **Marriages:**
  - First Marriage: Wife's name unknown
    - Children: Jeremy Kerr, Heather Kerr
  - Second Marriage: Debby Kerr (currently in Kalamazoo)
    - Children: Daniel Kerr, Ryan Kerr
- **Siblings:** Don Kerr, Vanessa Kerr Otsuka, Sharron Kerr
- **Research Gaps:**
  - Exact birth and death dates
  - Specific location and cause of death
  - First wife's identity
  - Occupation
  - Timeline of marriages and divorces

### Vanessa Kerr Otsuka (Paternal Aunt)
- **Full Name:** Vanessa Kerr Otsuka
- **Birth:** Unknown
- **Residence:** California
- **Parents:** Donald and Loraine Kerr
- **Spouse:** Richard Otsuka
- **Children:** Evan Otsuka, Bobby Otsuka (both played sports)
- **Step-child:** Richard's daughter from previous relationship (name unknown)
- **Siblings:** Don Kerr, Steve Kerr, Sharron Kerr
- **Research Gaps:**
  - Birth date
  - Education and occupation
  - Timeline of marriage to Richard Otsuka
  - When the family moved to California
  - Richard Otsuka's background and first marriage

### Sharron Kerr (Paternal Aunt, Deceased)
- **Full Name:** Sharron Kerr
- **Birth:** Unknown
- **Death:** Unknown (died young)
- **Parents:** Donald and Loraine Kerr
- **Marriages:**
  - First Marriage: Tom Decker
  - Second Marriage: Dick Grimms
- **Children:** Carey Grimms (with Dick Grimms)
- **Siblings:** Don Kerr, Steve Kerr, Vanessa Kerr Otsuka
- **Research Gaps:**
  - Exact birth and death dates
  - Age at death and cause
  - Timeline of marriages
  - Details about husbands Tom Decker and Dick Grimms
  - Additional children, if any

## Paternal Cousins

### Jeremy Kerr (Paternal Cousin)
- **Full Name:** Jeremy Kerr
- **Residence:** Louisiana
- **Parents:** Steve Kerr and his first wife
- **Siblings:** Heather Kerr
- **Half-siblings:** Daniel Kerr, Ryan Kerr
- **Research Gaps:**
  - Birth date
  - Occupation
  - Marital status and children, if any
  - When and why he moved to Louisiana

### Heather Kerr (Paternal Cousin)
- **Full Name:** Heather Kerr
- **Residence:** Sturgis or Three Rivers, Michigan
- **Parents:** Steve Kerr and his first wife
- **Siblings:** Jeremy Kerr
- **Half-siblings:** Daniel Kerr, Ryan Kerr
- **Research Gaps:**
  - Birth date
  - Occupation
  - Marital status and children, if any
  - Specific residence location

### Daniel Kerr (Paternal Cousin)
- **Full Name:** Daniel Kerr
- **Residence:** Detroit, Michigan
- **Parents:** Steve Kerr and his second wife Debby Kerr
- **Siblings:** Ryan Kerr
- **Half-siblings:** Jeremy Kerr, Heather Kerr
- **Research Gaps:**
  - Birth date
  - Occupation
  - Marital status and children, if any
  - When he moved to Detroit and why

### Ryan Kerr (Paternal Cousin)
- **Full Name:** Ryan Kerr
- **Residence:** Kalamazoo, Michigan (with mother)
- **Parents:** Steve Kerr and his second wife Debby Kerr
- **Siblings:** Daniel Kerr
- **Half-siblings:** Jeremy Kerr, Heather Kerr
- **Research Gaps:**
  - Birth date
  - Occupation or education status
  - Specific information about living with mother Debby in Kalamazoo

### Evan Otsuka (Paternal Cousin)
- **Full Name:** Evan Otsuka
- **Residence:** California
- **Parents:** Vanessa Kerr Otsuka and Richard Otsuka
- **Siblings:** Bobby Otsuka
- **Note:** Played sports
- **Research Gaps:**
  - Birth date
  - Specific sports played
  - Education and occupation
  - Marital status and children, if any

### Bobby Otsuka (Paternal Cousin)
- **Full Name:** Bobby Otsuka
- **Residence:** California
- **Parents:** Vanessa Kerr Otsuka and Richard Otsuka
- **Siblings:** Evan Otsuka
- **Note:** Played sports
- **Research Gaps:**
  - Birth date
  - Specific sports played
  - Education and occupation
  - Marital status and children, if any

### Carey Grimms (Paternal Cousin)
- **Full Name:** Carey Grimms
- **Parents:** Sharron Kerr and Dick Grimms
- **Research Gaps:**
  - Birth date
  - Current residence
  - Education and occupation
  - Marital status and children, if any
  - Relationship with the broader Kerr family after mother's early death

## Geographic Distribution

### Michigan
- Don Kerr family: Otsego (Jefferson Road)
- Steve Kerr's second wife and son: Kalamazoo (Debby and Ryan)
- Steve Kerr's daughter: Sturgis or Three Rivers (Heather)
- Steve Kerr's son: Detroit (Daniel)
- Original family base: Three Rivers/Sturgis area (St. Joseph County)

### Out of State
- **California**
  - Vanessa Kerr Otsuka family (Richard, Evan, Bobby)
  
- **Louisiana**
  - Jeremy Kerr

## Family Movement Patterns
- Original family base in Three Rivers/Sturgis area (St. Joseph County)
- Don Kerr moved to Otsego (Allegan County) with wife Debby, approximately 40 miles north
- Next generation shows broader geographic dispersal:
  - Migration to California (Vanessa's family)
  - Migration to Louisiana (Jeremy)
  - Urban migration to Detroit (Daniel)
  - Some retention in original family areas (Heather in Sturgis/Three Rivers)

## Naming Patterns
- Repetition of the name "Kerr" maintained through male lines
- No clear pattern of naming children after parents or grandparents within the paternal line
- More diversity in first names compared to maternal line
- Name "Richard" appears in both paternal extended family (Richard Otsuka) and maternal line (George Richard Mowry) - possible coincidence