# Paternal Grandparents

## Donald Kerr (Paternal Grandfather)
- **Full Name:** Donald Kerr
- **Birth Date:** Unknown (likely 1920s-1930s)
- **Birth Place:** Unknown (likely Michigan)
- **Death Date:** Unknown
- **Residence:** Three Rivers or Sturgis area, St. Joseph County, Michigan
- **Spouse:** Loraine Kerr
- **Children:**
  - Don Kerr (born December 8, circa 1950)
  - Steve Kerr (younger than Don, recently deceased)
  - Vanessa Kerr (now Otsuka)
  - Sharron Kerr (deceased at a young age)
- **Military Service:** Likely served as a paratrooper, possibly during World War II
- **Geographic Significance:** Possible connection to the naming of Kerr Creek Road in the Three Rivers/Sturgis area, suggesting significant family presence or land ownership
- **Research Gaps:**
  - Exact birth and death dates
  - Military service details and verification
  - Marriage date to Loraine
  - Occupation
  - Education background
  - Parents and siblings
  - Confirmation of connection to Kerr Creek Road

## Loraine Kerr (Paternal Grandmother)
- **Full Name:** Loraine Kerr (maiden name unknown)
- **Birth Date:** Unknown (likely 1920s-1930s)
- **Birth Place:** Unknown (likely Michigan)
- **Death Date:** Unknown
- **Residence:** Three Rivers or Sturgis area, St. Joseph County, Michigan
- **Spouse:** Donald Kerr
- **Children:**
  - Don Kerr (born December 8, circa 1950)
  - Steve Kerr (younger than Don, recently deceased)
  - Vanessa Kerr (now Otsuka)
  - Sharron Kerr (deceased at a young age)
- **Research Gaps:**
  - Maiden name
  - Exact birth and death dates
  - Marriage date to Donald
  - Occupation
  - Education background
  - Parents and siblings

## Temporal and Geographic Context
- Likely married in the 1940s, based on Don's birth around 1950
- Primarily associated with the Three Rivers/Sturgis area in St. Joseph County, Michigan
- Established significant presence in the area, potentially indicated by Kerr Creek Road naming
- Lived during World War II era, with Donald potentially serving as a paratrooper

## Family Significance
- Established the Kerr family presence in southwestern Michigan
- Began the paternal family line that eventually connected with the Mowry family through their son Don's marriage to Debby Mowry
- Contributed to military service tradition in the family through Donald's likely service as a paratrooper
- Created a family unit of four children, establishing the extended Kerr family network