# Maternal Grandparents

## Donna Mowry (Maternal Grandmother)
- **Full Name:** Donna Mowry (maiden name unknown)
- **Birth Date:** Unknown (likely 1920s-1930s)
- **Birth Place:** Unknown (likely Michigan)
- **Death Date:** Approximately March 5, 1984 (when grandson Jeff was about 9 years old)
- **Death Place:** Plainwell, Michigan
- **Residence:** Jefferson Road, Otsego, Allegan County, Michigan
- **Relationships:**
  - Relationship with George Richard Mowry (father of Debby)
  - Later relationship with Norman William "Bud" Lowe
- **Children:**
  - Debby Mowry (born February 3, circa 1948)
- **Property:** Owner of home on Jefferson Road in Otsego that was later sold to Don and Debby Kerr
- **Research Gaps:**
  - Maiden name
  - Exact birth date and location
  - Parents and siblings
  - Formal nature of relationship with Norman William "Bud" Lowe (legal marriage vs. partnership)
  - Possible connections to Georgia Newman, Cathy Merrit, Connie, Lisa
  - Complete details of relationship with George Richard Mowry

## George Richard Mowry (Maternal Biological Grandfather)
- **Full Name:** George Richard Mowry
- **Birth:** January 25, 1927, Kalamazoo, Michigan
- **Death:** October 8, 1955, Cooper Township, Kalamazoo, Michigan (age 28)
- **Burial:** Oak Grove Cemetery, Galesburg, Kalamazoo, Michigan
- **Parents:**
  - Father: George William Mowry (1907-1953)
  - Mother: Cornelia C Comings (1908-1997)
- **Spouse:** Patricia Corlyss Sheldon (married February 28, 1948 in Otsego Township, Allegan, Michigan)
- **Biological Father of:** Debby Mowry (born February 3, circa 1948)
- **Residence History:**
  - Lived in Comstock, Kalamazoo, Michigan in 1930
  - Lived in Otsego, Allegan, Michigan in 1940
- **Military Service:** Registered for military service in 1946
- **Complex Family Situation:** Married Patricia Corlyss Sheldon around the same time that Donna Mowry was pregnant with or had recently given birth to his daughter Debby
- **Research Gaps:**
  - Occupation
  - Cause of death at young age (28)
  - Nature of relationship with Donna Mowry
  - Relationship (if any) with daughter Debby after his marriage to Patricia
  - Potential children with Patricia Sheldon

## Norman William "Bud" Lowe (Maternal Grandmother's Partner)
- **Full Name:** Norman William Lowe
- **Nickname:** "Bud"
- **Birth:** April 3, 1925
- **Death:** October 3, 1989 (age 64)
- **Burial:** Mountain Home Cemetery, Otsego, Allegan County, Michigan
- **Military Service:** Corporal, US Army, Korea (as indicated on gravestone)
- **Relationship to Donna Mowry:** Long-term partner/possible spouse
- **Relationship to Debby:** Stepfather figure (not biological father)
- **Residence:** Likely lived with Donna Mowry on Jefferson Road, Otsego, Michigan
- **Research Gaps:**
  - Birth place
  - Parents and siblings
  - Previous marriages or relationships
  - Precise beginning of relationship with Donna Mowry
  - Legal status of relationship with Donna (formal marriage vs. partnership)
  - Occupation beyond military service
  - Potential biological children of his own

## Patricia Corlyss Sheldon (George Richard Mowry's Wife)
- **Full Name:** Patricia Corlyss Sheldon (married name Mowry)
- **Marriage:** To George Richard Mowry on February 28, 1948 in Otsego Township, Allegan, Michigan
- **Family Connection:** Likely related to Dean Sheldon (possibly brother, father, or other close relative)
- **Significance:** Married George Richard Mowry around the same time he had fathered a child (Debby) with Donna Mowry
- **Research Gaps:**
  - Birth and death information
  - Parents and other family members
  - Children with George Richard Mowry (if any)
  - Life after George's death in 1955
  - Exact relationship to Dean Sheldon

## Temporal and Geographic Context
- Family activities centered in Otsego/Plainwell area (Allegan County) and Kalamazoo
- Significant events clustered in late 1940s to mid-1950s:
  - Birth of Debby Mowry (circa February 1948)
  - Marriage of George and Patricia (February 28, 1948)
  - Death of George Richard Mowry (October 8, 1955)
- Norman "Bud" Lowe likely entered Donna's life after George's relationship ended, possibly after his Korean War service
- Donna owned the Jefferson Road home in Otsego until her death in 1984
- Norman survived Donna by about 5 years, dying in 1989

## Complex Family Formation
The maternal grandparent situation represents a complex family formation:
1. Donna Mowry had a relationship with George Richard Mowry resulting in the birth of Debby
2. George married Patricia Corlyss Sheldon around the same time
3. George died in 1955 when Debby would have been about 7 years old
4. Norman "Bud" Lowe became a father figure to Debby despite no biological connection
5. The Jefferson Road home in Otsego became a multi-generational family center, eventually transferring to Don and Debby Kerr