# Ancestral Tracing Plan: Extending the Kerr Family Tree Vertically

## Overview
This document outlines the strategic approach for tracing the Kerr and related family lines further back in time, with particular emphasis on identifying origins, immigration patterns, and connections to ancestral homelands. The goal is to extend our understanding of the family's deeper roots and historical context.

## Key Ancestry Lines for Vertical Expansion

### 1. Kerr Family Line (Paternal)
**Current Known Generations:**
- Jeff Kerr (born 1977)
- Don Kerr (born circa 1950)
- Donald Kerr (birth date unknown, likely 1920s-1930s)

**Research Objectives:**
- Trace the Kerr lineage back to its Scottish origins
- Identify when and where the Kerr family immigrated to America
- Discover connections to Kerr Creek Road naming in Three Rivers/Sturgis area
- Explore potential military service patterns across generations
- Identify siblings of Donald Kerr and their descendants

**Research Strategies:**
1. Census records from 1940, 1930, 1920, 1910 for Donald Kerr's parents
2. Birth records in St. Joseph County for Donald Kerr
3. Land records associated with Kerr Creek Road
4. Immigration and naturalization records for earliest Kerr ancestors
5. Scottish parish records for Kerr family origins
6. Military records for multiple generations of Kerr men
7. Social Security Applications and Claims Index for Donald Kerr
8. Newspaper archives from Three Rivers/Sturgis area

### 2. Loraine's Maiden Line (Paternal Grandmother)
**Current Known Information:**
- Loraine Kerr (maiden name unknown, birth date unknown)

**Research Objectives:**
- Identify Loraine's maiden name
- Trace her family origins and heritage
- Discover potential connections to other known family lines
- Identify her parents and siblings

**Research Strategies:**
1. Marriage record for Donald and Loraine Kerr
2. Birth records for their children (Don, Steve, Vanessa, Sharron)
3. Death certificate for Loraine if deceased
4. Census records showing Loraine as a child in her parents' household
5. Obituaries for Loraine or her siblings
6. Social Security Applications and Claims Index
7. Local newspaper social columns from Three Rivers/Sturgis area

### 3. Mowry Family Line (Maternal)
**Current Known Generations:**
- Debby Mowry (born circa 1948)
- George Richard Mowry (1927-1955)
- George William Mowry (1907-1953) and Cornelia C Comings (1908-1997)

**Research Objectives:**
- Trace the Mowry family back beyond George William Mowry
- Explore the Comings family line
- Identify siblings of George William Mowry and Cornelia Comings
- Discover the origin of the Mowry surname and immigration patterns
- Identify potential religious or community affiliations

**Research Strategies:**
1. Census records for Mowry and Comings families from 1940 back to 1880
2. Birth and marriage records for George William Mowry and Cornelia Comings
3. Birth records for any siblings of George Richard Mowry
4. Cemetery records from Oak Grove Cemetery, Galesburg
5. Probate records for George William Mowry (died 1953)
6. Newspaper obituaries and local histories
7. Church records from Kalamazoo and Allegan Counties
8. Land and property records for Mowry family

### 4. Donna's Family Line (Maternal Grandmother)
**Current Known Information:**
- Donna Mowry (maiden name unknown, died circa 1984)

**Research Objectives:**
- Identify Donna's maiden name
- Trace her family origins
- Discover her parents and siblings
- Explore possible connections to mentioned individuals (Georgia Newman, Cathy Merrit, Connie, Lisa)
- Document her life before relationship with George Richard Mowry

**Research Strategies:**
1. Death certificate from 1984 in Plainwell, Michigan
2. Birth record for daughter Debby (circa 1948)
3. Census records prior to 1948
4. Marriage records (if any) in Allegan County
5. Property records for Jefferson Road home in Otsego
6. Local newspaper social columns and obituaries
7. Church records from Otsego/Plainwell area
8. High school yearbooks and records

### 5. Lowe Family Line (Norman "Bud" Lowe)
**Current Known Information:**
- Norman William "Bud" Lowe (1925-1989)
- Served in Korean War as Corporal, US Army

**Research Objectives:**
- Identify Norman's parents and siblings
- Trace Lowe family origins
- Explore military service history
- Document his life before relationship with Donna Mowry
- Identify potential step-family connections to Debby

**Research Strategies:**
1. Birth record for Norman William Lowe (1925)
2. Census records from 1930 and 1940 showing him as a child
3. Military service records from Korean War
4. Mountain Home Cemetery records in Otsego
5. Marriage records (if any) between Norman and Donna
6. Obituary from 1989
7. Veterans' organization membership records
8. Draft registration cards

### 6. Sheldon Family Line (Connection through Patricia)
**Current Known Information:**
- Patricia Corlyss Sheldon (married George Richard Mowry in 1948)
- Potential relation to Dean Sheldon
- Possible connection to Diana (potentially née Sheldon) and Bill Cole

**Research Objectives:**
- Identify Patricia's parents and siblings
- Confirm relationship between Patricia and Dean Sheldon
- Explore potential connection to Diana Cole
- Trace Sheldon family presence in Allegan County
- Document Patricia's life after George Richard Mowry's death in 1955

**Research Strategies:**
1. Marriage record from February 28, 1948 in Otsego Township
2. Census records for Sheldon family in Allegan County
3. Birth record for Patricia Corlyss Sheldon
4. Death record for George Richard Mowry (1955) to see if Patricia was informant
5. Remarriage records for Patricia after 1955
6. Local church and community records
7. School records and yearbooks
8. Social media and current records for living Sheldon descendants

## Genealogical Methods for Vertical Expansion

### 1. Census Record Tracing
- Systematically track families backward through decennial census records
- Use census records to identify household compositions, occupations, and locations
- Create census timelines showing family movements and changes

### 2. Vital Records Research
- Locate birth, marriage, and death certificates for all identified ancestors
- Use information from these records to identify parents' names and birthplaces
- Build evidence chains linking generations through official documentation

### 3. Immigration and Naturalization Research
- Identify approximate immigration timeframes through census "year of immigration" data
- Search passenger lists and ship manifests for family names
- Locate naturalization records for first-generation American ancestors
- Research alien registration records from 1940s

### 4. Land and Property Record Analysis
- Research property ownership records in counties where families resided
- Follow land transactions to identify family movements and relationships
- Pay special attention to Kerr Creek Road area and Jefferson Road property
- Look for wills and probate records that mention land transfers

### 5. Military Service Tracing
- Research military service records across generations:
  - Donald Kerr (potential WWII paratrooper service)
  - Norman William Lowe (Korean War)
  - George Richard Mowry (registered for service in 1946)
  - Earlier ancestors in WWI, Spanish-American War, or Civil War
- Use military pension records to gather family information
- Research veterans' grave registrations and memorial records

### 6. Religious and Community Record Research
- Identify potential church affiliations for family branches
- Research baptismal, confirmation, and membership records
- Explore fraternal organization records (Masons, Elks, etc.)
- Investigate ethnic or cultural society memberships

### 7. Newspaper Research
- Conduct systematic searches of local newspaper archives:
  - Birth, marriage, and death announcements
  - Social columns mentioning family activities
  - Business advertisements for family enterprises
  - Local history features mentioning family names
- Focus on newspapers from:
  - Three Rivers/Sturgis area
  - Otsego/Plainwell area
  - Kalamazoo
  - Grand Rapids
  
### 8. DNA and Genetic Genealogy (if available)
- Analyze any available DNA test results to identify genetic cousins
- Use genetic connections to verify paper trail research
- Identify unexpected connections that may not appear in documents
- Explore ethnicity estimates for clues to ancestral origins

## Ancestry Challenges and Strategies

### Challenge: Missing Maiden Names
**Strategy:**
- Search marriage records in likely counties
- Check children's birth certificates for mother's maiden name
- Examine death certificates for parental information
- Review obituaries for mentions of birth families
- Research siblings who may have more complete records

### Challenge: Immigrant Origins
**Strategy:**
- Document most recent known generation thoroughly
- Search census records for "place of birth" entries
- Review naturalization petitions for specific origin locations
- Research ethnic community organizations and publications
- Examine church records for immigrant congregations

### Challenge: Adoption or Non-Biological Relationships
**Strategy:**
- Document all known relationships clearly
- Look for discrepancies in surnames or unexpected name changes
- Search for adoption records where legally accessible
- Examine census records for blended families
- Pay attention to guardian relationships in legal documents

### Challenge: Distinguishing Between Same-Named Individuals
**Strategy:**
- Create detailed timelines for each individual
- Document all known associates and family members
- Note consistent use of middle names or initials
- Track residences carefully to separate individuals
- Use occupation and age information to distinguish individuals

## Timeline Approach for Ancestral Research

### 1940s-Present (Already Documented)
- Current focus of family history
- Well-documented through family knowledge and records

### 1910s-1940s (First Extension Priority)
- Parents and early lives of Donald and Loraine Kerr
- Parents and early lives of Donna Mowry and Norman Lowe
- Childhood of George William Mowry and Cornelia Comings
- Effects of Great Depression and World Wars on family

### 1880s-1910s (Second Extension Priority)
- Grandparents of Donald and Loraine Kerr
- Grandparents of Donna Mowry and Norman Lowe
- Great-grandparents of Debby Mowry
- Family life during industrialization and early automobile era

### Pre-1880s (Third Extension Priority)
- Immigration generation for each family line
- Scottish origins of Kerr family
- Origins of Mowry, Comings, Lowe, and other surnames
- Family life during Civil War era and earlier

## Output Documents for Ancestral Research

### Ancestral Lines Documentation
- Detailed lineage charts for each surname line
- Documentation of evidence chains connecting generations
- Narrative histories of each family branch

### Immigration and Origin Stories
- Detailed accounts of when and how families came to America
- Research on ancestral villages or regions in countries of origin
- Cultural and historical context for immigration decisions

### Extended Genealogical Database
- Comprehensive family tree extending at least 3-4 generations back from Donald and Loraine Kerr
- Complete source citations for all relationships
- Confidence ratings for each connection

### Timeline of Ancestral Events
- Multi-generational timeline showing family events in historical context
- Patterns of family formation, migration, and occupation across generations
- Visualization of how historical events affected family decisions

### Narrative History of Family Origins
- Compelling storytelling about the origins of each family line
- Cultural context for different ancestral groups
- Explanation of naming patterns, traditions, and migrations